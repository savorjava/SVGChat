//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGShapeCubicCurve.java

import java.awt.*;
import java.awt.geom.*;

public class SVGShapeCubicCurve extends SVGShape
{
   private CubicCurve2D cubicCurve = new CubicCurve2D.Double(
      0, 0, Math.random() * 20, Math.random() * 20,
      Math.random() * 20, Math.random() * 20, 0, 0);


   public SVGShapeCubicCurve()
   {
      cubicCurve = new CubicCurve2D.Double();
   }

   /**
   @roseuid 3C766E600055
   */
   public void draw(Graphics g)
   {
      super.draw(g);

      rectangle = cubicCurve.getBounds();
      Graphics2D g2 = (Graphics2D)g;
      AffineTransform old = g2.getTransform();
      g2.scale(scale, scale);
      g2.rotate(angle, Math.abs(((Point2D)positions.get(1)).getX() -
         rectangle.getWidth() / 2),
         Math.abs(((Point2D)positions.get(1)).getY() -
         rectangle.getBounds().getHeight() / 2));
      g2.setStroke(stroke);
      if(isFill)
      {
         g2.setColor(fillColor);
         g2.fill(cubicCurve);
      }
      else
      {
         g2.setColor(drawColor);
         g2.draw(cubicCurve);
      }
      g2.setTransform(old);
      generateSVG();
//      System.out.println(SVGFormat);
   }

   public void addPosition(Point2D p2)
   {
         positions.add(p2);
         Point2D p21 = new Point2D.Double(p2.getX(), p2.getY() + 4);
         Point2D p22 = new Point2D.Double(p2.getX() + 2, p2.getY() + 2);
         Point2D p23 = new Point2D.Double(p2.getX() - 2, p2.getY() + 2);
         positions.add(p21);
         positions.add(p22);
         positions.add(p23);
   }

   public void setPosition(Point2D p2, int address)
   {
      positions.set(address - 1, p2);
      cubicCurve.setCurve((Point2D)positions.get(0),
         (Point2D)positions.get(2), (Point2D)positions.get(3),
         (Point2D)positions.get(1));
   }

   public void setCurve(Point2D p1, Point2D c1, Point2D c2, Point2D p2)
   {
      positions.set(0, p1);
      positions.set(1, p2);
      positions.set(2, c1);
      positions.set(3, c2);
      cubicCurve.setCurve((Point2D)positions.get(0),
         (Point2D)positions.get(2), (Point2D)positions.get(3),
         (Point2D)positions.get(1));
   }

   public void setSelected(boolean b)
   {
      selected = b;
   }

   public String toString()
   {
      return "CubicCurve:" + cubicCurve.getX1()+ "," + cubicCurve.getY1() + " - " +
         cubicCurve.getX2() + "," + cubicCurve.getY2();
   }

   public void generateSVG()
   {

      SVGFormat = "<path d=\"M" + cubicCurve.getX1() + "," +
         cubicCurve.getY1() + " C" + cubicCurve.getCtrlX1() + "," +
         cubicCurve.getCtrlY1() + "," + cubicCurve.getCtrlX2() + "," +
         cubicCurve.getCtrlY2() + " " + cubicCurve.getX2() + "," +
         cubicCurve.getY2() + "\" " +
         "stroke=\"" +
         (!isFill ? "#" + Integer.toHexString(drawColor.getRGB()).substring(2) : "none") + "\" " +
         "fill=\"" +
         (isFill ? "#" + Integer.toHexString(fillColor.getRGB()).substring(2) : "none") + "\" " +
         "stroke-width=\"" + lineWidth + "\" " +
         "/>";
   }
}
