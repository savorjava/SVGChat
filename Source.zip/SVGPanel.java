//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGPanel.java

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.io.*;
import java.io.File;
import javax.swing.filechooser.*;



public class SVGPanel extends JPanel
{
   private ArrayList vectorImages = new ArrayList(20);
   private SVGImage vectorImage = new SVGImage();

   private BufferedImage bufferedImage;
   private Graphics2D graphics2;
   private Graphics2D bufferedGraphics;
   private boolean init = true;           //first run paint() will init image and graphics.
   private Color currentColor = Color.black; //default draw color is black.
   private String currentShape = "";  //no choose any shape when application begin

   private File file;      //this file is for saving and loading SVG File.
   private String fileName = "NewWork";
   private boolean modified = false;   //this meant if you have done something on SVGPanel.


   public SVGPanel()
   {
      setBackground(new Color(235, 235, 235));
      vectorImages.add(vectorImage);
   }

   /**
   @roseuid 3C79102E00CC
   */
   public void paintComponent(Graphics g)
   {
      super.paintComponent(g);
//      if(init)
//         init(g);
      graphics2 = (Graphics2D)g;
      vectorImage.drawSVG(g);
      setModified(true);

//      g.drawRect(0, 0, getSize().width - 1, getSize().height - 1);
   }

   public void init(Graphics g)
   {
      graphics2 = (Graphics2D)g;
      bufferedImage = new BufferedImage(getSize().width, getSize().height,
         BufferedImage.TYPE_INT_RGB);
      bufferedGraphics = (Graphics2D)bufferedImage.getGraphics();
      if(bufferedImage == null)
         System.out.println("image is null");
      init = false;
   }


   public Color getCurrentColor()
   {
      return currentColor;
   }

   public void setCurrentColor(Color c)
   {
      currentColor = c;
   }

   public void setCurrentShape(String name)
   {
      currentShape = name;
   }

   public void setSelectedShape(int index)
   {
      vectorImage.setSelectedShape(index);
   }

   public int getSelectedShape()
   {
      return vectorImage.getSelectedShape();
   }

   public String getCurrentShape()
   {
      return currentShape;
   }

   //get a new special shape from vectorImage
   public SVGShape getNewShape()
   {
      if(currentShape.equals("Line"))
         return vectorImage.buildLine();
      else if(currentShape.equals("Rectangle"))
         return vectorImage.buildRect();
      else if(currentShape.equals("RoundRectangle"))
         return vectorImage.buildRound();
      else if(currentShape.equals("Ellipse"))
         return vectorImage.buildEllipse();
      else if(currentShape.equals("Arc"))
         return vectorImage.buildArc();
      else if(currentShape.equals("CubicCurve"))
         return vectorImage.buildCubicCurve();
      else if(currentShape.equals("Text"))
         return vectorImage.buildText();
      else return null;

   }

   //get current shape in vectorImage
   public SVGShape getShape()
   {
      return vectorImage.getCurrentShape();
   }

   //tell me if the SVGImage is empty
   public boolean isEmpty()
   {
      if(vectorImage.getImageSize() == 0)
         return true;
      else
         return false;
   }

   public ArrayList getAllShapes()
   {
      return vectorImage.getAllShapes();
   }


   //check if the panel need to be saved.
   public boolean checkSaved()
   {
      return !modified;
   }

   //mark if panel have been modified.
   public void setModified(boolean m)
   {
      modified = m;
   }

   //save the shapes into SVG format file.
   public boolean saveFile()
   {
      JFileChooser chooser = new JFileChooser();
      SVGFileFilter filter = new SVGFileFilter();
      filter.addExtension("svg");
      filter.setDescription("Scalable Vector Graphics");
      chooser.setFileFilter(filter);
      int returnVal = chooser.showOpenDialog(getRootPane().getParent());
      if(returnVal == JFileChooser.APPROVE_OPTION) {
         System.out.println("You chose to open this file: " +
            chooser.getSelectedFile().getName());
         file = chooser.getSelectedFile();
         if(file.exists())
         {
            int n = JOptionPane.showOptionDialog(getRootPane().getParent(),
                "File " + chooser.getSelectedFile().getName()
                + "has existed. Do you want to replace it ?",
                "Saving you file...",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null, null, null);
            if(n ==  JOptionPane.YES_OPTION)
            {
               //begin to save.
               try
               {
                  FileWriter out = new FileWriter(file);
                  out.write(vectorImage.getSVG());
                  out.close();
               }
               catch(IOException e)
               {
                  System.out.println("The file " + file.getName() + "has something wrong!");
               }


               return true;
            }
            else if((n == JOptionPane.NO_OPTION)||(n == JOptionPane.CANCEL_OPTION))
            {
               return false;
            }
         }
         else
         {
            try
            {
               FileWriter out = new FileWriter(file);
               out.write(vectorImage.getSVG());
               out.close();
            }
            catch(IOException e)
            {
               System.out.println("The file " + file.getName() + "has something wrong!");
            }
         }
      }

      return true;

   }

   //load the shapes into current SVGPanel.
   public String loadFile()
   {
      char content[] = null;
      JFileChooser chooser = new JFileChooser();
      SVGFileFilter filter = new SVGFileFilter();
      filter.addExtension("svg");
      filter.setDescription("Scalable Vector Graphics");
      chooser.setFileFilter(filter);
      int returnVal = chooser.showOpenDialog(getRootPane().getParent());
      if(returnVal == JFileChooser.APPROVE_OPTION) {
         System.out.println("You chose to open this file: " +
            chooser.getSelectedFile().getName());
         file = chooser.getSelectedFile();
         if(file.exists())
         {
            FileReader in;
            content = new char[(int)file.length()];
            try
            {
               in = new FileReader(file);
               in.read(content, 0, (int)file.length());
            }
            catch(FileNotFoundException fnfe)
            {
               System.out.println(fnfe);
            }
            catch(IOException ioe)
            {
               System.out.println(ioe);
            }
//            System.out.println(content);
         }
         else
         {
            JOptionPane.showMessageDialog(
               null, "File is not exist!", "alert", JOptionPane.ERROR_MESSAGE);
         }
      }

      return new String(content);

   }

   class SVGFileFilter extends javax.swing.filechooser.FileFilter
   {
      private Hashtable filters = null;
      private String description = null;
      private String fullDescription = null;
      private boolean useExtensionsInDescription = true;

      public SVGFileFilter()
      {
   	   this.filters = new Hashtable();
      }

      public SVGFileFilter(String extension, String description)
      {
	      this();
	      if(extension!=null) addExtension(extension);
 	      if(description!=null) setDescription(description);

      }

      public String getDescription()
      {
      	if(fullDescription == null) {
	         if(description == null || isExtensionListInDescription()) {
 		         fullDescription = description==null ? "(" : description + " (";
		         // build the description from the extension list
		         Enumeration extensions = filters.keys();
               if(extensions != null) {
		            fullDescription += "." + (String) extensions.nextElement();
		            while (extensions.hasMoreElements()) {
			            fullDescription += ", " + (String) extensions.nextElement();
		            }
		         }
		         fullDescription += ")";
	         }
            else{
		         fullDescription = description;
            }
	      }
	      return fullDescription;
      }

      public void setDescription(String description)
      {
   	   this.description = description;
	      fullDescription = null;
      }

      public boolean accept(File f)
      {
         if(f != null) {
            if(f.isDirectory()) {
   		      return true;
	         }
	         String extension = getExtension(f);
	         if(extension != null && filters.get(getExtension(f)) != null) {
		         return true;
	         };
	      }
	      return false;
      }

      public void addExtension(String extension) {
	      if(filters == null) {
	         filters = new Hashtable(5);
	      }
	      filters.put(extension.toLowerCase(), this);
	      fullDescription = null;
      }

      public String getExtension(File f) {
	      if(f != null) {
	         String filename = f.getName();
	         int i = filename.lastIndexOf('.');
	         if(i>0 && i<filename.length()-1) {
		      return filename.substring(i+1).toLowerCase();
	         };
	      }
	      return null;
      }

      public boolean isExtensionListInDescription() {
	      return useExtensionsInDescription;
      }

   }




   //get a empty SVGPanel and check if the file need to be saved.
   public void newFile()
   {
      vectorImage = new SVGImage();
      vectorImages.add(vectorImage);
      modified = false;
   }

   //add a new SVGimage from net or file into SVGPanel
   public void addImage(SVGImage img)
   {
      vectorImage = img;
      vectorImages.add(vectorImage);
      modified = false;
   }



   //get current image on this SVGPanel.
   public SVGImage getImage()
   {
      return vectorImage;
   }

   public void setSelectedSVG(int index)
   {
      vectorImage = (SVGImage)vectorImages.get(index);
   }



}
