

/**
 * Title:        SVGChat
 * Description:  This system is for chating with SVG(Scalable Vector Graphics).
 * Copyright:    Copyright (c) 2002
 * Company:      HUST
 * @author Sha Jin
 * @version 1.0
 */

//import java.io.*;
import org.xml.sax.*;
import org.xml.sax.helpers.ParserFactory;
//import javax.xml.parsers.SAXParserFactory;
//import javax.xml.parsers.SAXParser;
//import javax.xml.parsers.ParserConfigurationException;
import org.apache.xerces.parsers.*;
import java.io.*;
import java.awt.*;
import java.awt.geom.*;

public class SVGParser extends HandlerBase
{

   private String SVG;
   private SVGPanel vectorPanel;
//   private SAXParserFactory factory;
   private SAXParser saxParser;
   private SVGImage image;
   private SVGShapeText text = new SVGShapeText();
   private String textContent;


   public SVGParser(SVGPanel vp)
   {
      vectorPanel = vp;
   }

   public SVGImage parserInit(String svg)
   {
//      factory = SAXParserFactory.newInstance();
//      factory.setNamespaceAware(true);
//      factory.setValidating(true);
//         saxParser = factory.newSAXParser();
      SVG = svg;
      saxParser = new SAXParser();
      StringReader sr = new StringReader((SVG == null) ? "" : SVG);
      InputSource iSrc = new InputSource(sr);
      saxParser.setDocumentHandler(this);
      saxParser.setErrorHandler(this);

      try
      {
         saxParser.parse(iSrc);
      }
      catch (Exception e)
      {
         System.out.println("Parse: " + e);
      }
/*      catch (SAXException se)
      {
         // handle error
         System.out.println("SAX :" + se);
      }
      catch (IOException ioe)
      {
         // handle error
         System.out.println("IO :" + ioe);
      }
      catch (ParserConfigurationException pce)
      {
         // handle error
         System.out.println("Parser configuration :" + pce);
      }*/
      return image;
   }

   public void processingInstruction(String target, String data)
   {
      System.out.println("this is instruction element!");
   }

   public void startDocument()
   {
      System.out.println("XML file start!");
      image = new SVGImage();
   }

   public void startElement(String name, AttributeList attrs)
   {
      System.out.println(name + " element start!");
      if(name.equals("line"))
      {
         SVGShapeLine line = new SVGShapeLine();
         line.addPosition(new Point2D.Double(
            Double.parseDouble(attrs.getValue("x1")),
            Double.parseDouble(attrs.getValue("y1"))));
         line.setPosition(new Point2D.Double(
            Double.parseDouble(attrs.getValue("x2")),
            Double.parseDouble(attrs.getValue("y2"))), 2);
         line.setLineWidth(Integer.parseInt(attrs.getValue("stroke-width")));
         line.drawColor = new Color(
            Integer.valueOf(
               attrs.getValue("stroke").substring(1), 16).intValue());
         line.selected = false;
         image.addShape(line);
      }
      else if(name.equals("rect"))
      {
         SVGShape rect;
         if(attrs.getValue("rx") == null)
            rect = new SVGShapeRectangle();
         else
         {
            rect = new SVGShapeRoundRectangle();
            ((SVGShapeRoundRectangle)rect).setRoundX(
               (int)Double.parseDouble(attrs.getValue("rx")));
            ((SVGShapeRoundRectangle)rect).setRoundY(
               (int)Double.parseDouble(attrs.getValue("ry")));
         }
         rect.addPosition(new Point2D.Double(
            Double.parseDouble(attrs.getValue("x")),
            Double.parseDouble(attrs.getValue("y"))));
         rect.setPosition(new Point2D.Double(
            Double.parseDouble(attrs.getValue("width")) +
               Double.parseDouble(attrs.getValue("x")),
            Double.parseDouble(attrs.getValue("height")) +
               Double.parseDouble(attrs.getValue("y"))), 2);
         rect.setLineWidth(Integer.parseInt(attrs.getValue("stroke-width")));
         if(!attrs.getValue("stroke").equals("none"))
            rect.drawColor = new Color(
               Integer.valueOf(
                  attrs.getValue("stroke").substring(1), 16).intValue());
         if(!attrs.getValue("fill").equals("none"))
         {
            rect.fillColor = new Color(
               Integer.valueOf(
                  attrs.getValue("fill").substring(1), 16).intValue());
            rect.setFill(true);
         }
         rect.selected = false;
         image.addShape(rect);
      }
      else if(name.equals("ellipse"))
      {
         SVGShapeEllipse ellipse = new SVGShapeEllipse();
         ellipse.addPosition(new Point2D.Double(
            Double.parseDouble(attrs.getValue("cx")) -
               Double.parseDouble(attrs.getValue("rx")),
            Double.parseDouble(attrs.getValue("cy")) -
               Double.parseDouble(attrs.getValue("ry"))));
         ellipse.setPosition(new Point2D.Double(
            Double.parseDouble(attrs.getValue("rx")) +
               Double.parseDouble(attrs.getValue("cx")),
            Double.parseDouble(attrs.getValue("ry")) +
               Double.parseDouble(attrs.getValue("cy"))), 2);
         ellipse.setLineWidth(Integer.parseInt(attrs.getValue("stroke-width")));
         if(!attrs.getValue("stroke").equals("none"))
            ellipse.drawColor = new Color(
               Integer.valueOf(
                  attrs.getValue("stroke").substring(1), 16).intValue());
         if(!attrs.getValue("fill").equals("none"))
         {
            ellipse.fillColor = new Color(
               Integer.valueOf(
                  attrs.getValue("fill").substring(1), 16).intValue());
            ellipse.setFill(true);
         }
         ellipse.selected = false;
         image.addShape(ellipse);
      }
      else if(name.equals("text"))
      {
         text.addPosition(new Point2D.Double(
            Double.parseDouble(attrs.getValue("x")),
            Double.parseDouble(attrs.getValue("y"))));
         text.setPosition(new Point2D.Double(
            Double.parseDouble(attrs.getValue("x")),
            Double.parseDouble(attrs.getValue("y"))), 2);
         text.setFontName(attrs.getValue("font-family"));
         text.setLineWidth(Integer.parseInt(attrs.getValue("font-size")));
         text.drawColor = new Color(
            Integer.valueOf(
               attrs.getValue("fill").substring(1), 16).intValue());
      }
      else if(name.equals("path"))
      {
         SVGShape path;
         if(attrs.getValue("d").indexOf("C") != -1)
         {
            path = new SVGShapeCubicCurve();
            String m = attrs.getValue("d").substring(1,
               attrs.getValue("d").indexOf(" "));
            Point2D.Double p1 = new Point2D.Double(
               Double.parseDouble(m.substring(0, m.indexOf(","))),
               Double.parseDouble(m.substring(m.indexOf(",") + 1)));
            String c = attrs.getValue("d").substring(
               attrs.getValue("d").indexOf("C") + 1);
            double x = Double.parseDouble(c.substring(0, c.indexOf(",")));
            c = c.substring(c.indexOf(",") + 1);
            double y = Double.parseDouble(c.substring(0, c.indexOf(",")));
//            System.out.println("c1: " + x + "," + y);
            c = c.substring(c.indexOf(",") + 1);
            Point2D.Double c1 = new Point2D.Double(x, y);
            x = Double.parseDouble(c.substring(0, c.indexOf(",")));
            c = c.substring(c.indexOf(",") + 1);
            y = Double.parseDouble(c.substring(0, c.indexOf(" ")));
//            System.out.println("c2: " + x + "," + y);
            c = c.substring(c.indexOf(" ") + 1);
            Point2D.Double c2 = new Point2D.Double(x, y);
            x = Double.parseDouble(c.substring(0, c.indexOf(",")));
            c = c.substring(c.indexOf(",") + 1);
            y = Double.parseDouble(c.substring(0));
//            System.out.println("p2: " + x + "," + y);
            Point2D.Double p2 = new Point2D.Double(x, y);
            ((SVGShapeCubicCurve)path).addPosition(p1);
            ((SVGShapeCubicCurve)path).setCurve(p1, c1, c2, p2);
            path.setLineWidth(Integer.parseInt(attrs.getValue("stroke-width")));
            if(!attrs.getValue("stroke").equals("none"))
               path.drawColor = new Color(
                  Integer.valueOf(
                     attrs.getValue("stroke").substring(1), 16).intValue());
            if(!attrs.getValue("fill").equals("none"))
            {
               path.fillColor = new Color(
                  Integer.valueOf(
                  attrs.getValue("fill").substring(1), 16).intValue());
               path.setFill(true);
            }
         }
         else
         {
            String x = attrs.getValue("stroke").substring(1, 4);
            String y = attrs.getValue("stroke").substring(4, 7);
            String s = attrs.getValue("fill").substring(1, 4);
            String e = attrs.getValue("fill").substring(4, 7);
            String a = attrs.getValue("d").substring(
               attrs.getValue("d").indexOf("a"));
            a = a.substring(1, a.indexOf(" "));
            String w = a.substring(0, a.indexOf(","));
            String h = a.substring(a.indexOf(",") + 1);
//            System.out.println("Arc: " + s + "," + e);
            path = new SVGShapeArc();
            path.addPosition(new Point2D.Double(
               Double.parseDouble(x),
               Double.parseDouble(y)));
            ((SVGShapeArc)path).setPosition(new Point2D.Double(
               Double.parseDouble(w) * 2 + Double.parseDouble(x),
               Double.parseDouble(h) * 2 + Double.parseDouble(y)), 2);
            path.setLineWidth(Integer.parseInt(attrs.getValue("stroke-width")));
            ((SVGShapeArc)path).setStartAngle(Integer.parseInt(s));
            ((SVGShapeArc)path).setArcAngle(Integer.parseInt(e));
            ((SVGShapeArc)path).setFill(true);

         }
         path.selected = false;
         image.addShape(path);

      }
   }

   public void characters(char ch[], int start, int length)
   {
      System.out.print(new String(ch, start, length));
      textContent = new String(ch, start, length);
   }

   public void endDocument()
   {
      System.out.println("the document end!");
      vectorPanel.addImage(image);
   }

   public void endElement(String name)
   {
      System.out.println(name + " element end!");
      if(name.equals("text"))
      {
         text.setText(textContent);
         text.selected = false;
         image.addShape(text);
      }
   }

   // handle warning.
   public void warning(SAXParseException ex)
   {
      System.out.println("warning : " + ex);
   }

   // handle general error.
   public void error(SAXParseException ex)
   {
      System.out.println("parse error: " + ex);
   }

   // handle fatal error.
   public void fatalError(SAXParseException ex)
   throws SAXException
   {
      System.out.println("fatal error: " + ex);
      throw ex;
   }



}