//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGChatServer.java

import java.net.*;
import java.io.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.event.*;

public class SVGChatServer implements ActionListener
{
   private User user;
   private ChatLog chatLog;
   private ChatInfo chatInfo;
   private ServerSocket serverSocket;
   private Socket socket;
   private HashMap outputStreams = new HashMap();
   public ChatInfo theChatInfo[];
   public ChatLog theChatLog;
   public User theUser[];
   public ChatServerFrame theChatServerFrame;
   private ChatServerFrame serverFrame;

   private static String chatTitle = "ʸ��ͼ��������";
   private int port = 4321;
   private boolean running = false;
   private ArrayList users = new ArrayList(40);
   private int counter = 0;

   public SVGChatServer()
   {
      serverFrame = new ChatServerFrame(chatTitle, this);
      serverFrame.show();
   }

   /**
   @roseuid 3C7C80060209
   */
   public static void main(String[] args)
   {
      SVGChatServer chatServer = new SVGChatServer();
      if(args.length == 2)
      {
         chatServer.chatTitle = args[0];
         chatServer.port = Integer.parseInt(args[1]);
      }
      if(args.length == 1)
      {
         chatServer.chatTitle = args[0];
      }
      System.out.println("length " +args.length);
      System.out.println("usage: java -jar SVGChatServer [string] [port]");
      System.out.println("example: java -jar SVGChatServer");
      System.out.println("     or  java -jar SVGChatServer ChatRoom 4321");
      System.out.println("     or  java -jar SVGChatServer JavaForum");

      //begin the server application

      chatServer.init();
   }

   public void init()
   {

      try
      {
         serverSocket = new ServerSocket(port);
         running = true;
         while(running)
         {
            socket = serverSocket.accept();
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            outputStreams.put( socket, out );
            counter++;
            serverFrame.setStatus("Users: " + counter);
            System.out.println("Connecting Clients: " + counter);
            Thread t = new ThreadedHandler(this, socket , out, counter);
            t.start();
         }
      }
      catch(IOException e)
      {
         System.out.println("ServerSocket has something wrong: " + e);
         System.exit(1);
      }

   }

   public void actionPerformed(ActionEvent evt)
   {
      try
      {
         if(evt.getActionCommand().equals("Stop All Clients"))
         {
            for(Iterator i = outputStreams.values().iterator(); i.hasNext();)
               ((ObjectOutputStream)i.next()).close();
            serverFrame.setStatus("Users: 0");
         }
         else if(evt.getActionCommand().equals("Close Server"))
         {
            for(Iterator i = outputStreams.values().iterator(); i.hasNext();)
               ((ObjectOutputStream)i.next()).close();
            System.exit(0);
         }
      }
      catch(IOException ioe)
      {
         System.out.println(ioe);
      }
   }



   public class ThreadedHandler extends Thread
   {
      private SVGChatServer server;
      private Socket incoming;
      private int counter;
      private boolean first = true;
      private ChatInfo chatInfo;
      private ObjectInputStream in = null;
      private ObjectOutputStream out = null;
      private boolean done = false;
      private String username;

      public ThreadedHandler()
      {
      }

      public ThreadedHandler(SVGChatServer ss, Socket s , ObjectOutputStream oos, int c)
      {
         server = ss;
         incoming = s;
         counter = c;
         try
         {
            in = new ObjectInputStream(incoming.getInputStream());
            out = oos;
         }
         catch(IOException e)
         {
            System.out.println("one of the connections has something wrong: " + e);
         }
      }

      /**
      @roseuid 3C7B50C20168
      */
      public void run()
      {
         try
         {
            while(!done)
            {
               try
               {
                  sleep(700);
               }
               catch(InterruptedException ie)
               {
                  System.out.println(ie);
               }
               chatInfo = (ChatInfo)in.readObject();

               //user's command is close the connection!
               if(chatInfo.getCommand().equals("COMM:CLOSE"))
               {
                  out.writeObject(chatInfo);
                  System.out.println("server will off this connection" );
                  done = true;
               }
               //system will check if the login name have existed
               if(first && !done)
               {
                  username = chatInfo.getCommand().substring(5);
                  first = false;
                  for(int i = 0; i< users.size(); i++)
                  {
                     if(((String)users.get(i)).equals(username))
                     {
                        //tell the client must re-input a new name
                        out.writeObject(new ChatInfo("INFO:DUP", null, null));
                        first = true;
                        break;
                     }
                  }
                  if(!first)
                  {
                     //the login name is ok, add to list and infor all clients.
                     users.add(username);
                     chatInfo.setCommand("COMM:PUSH");
                     chatInfo.setChatWords("Welcome \"" + username + "\"'s coming!");
                     chatInfo.setUsers(users);
                  }
               }
               if(!first && !done)
               {
                  System.out.println("this is not first!" + users.size());
                  chatInfo.setUsers(users);
                  server.sendtoAll(chatInfo);
                  System.out.println(chatInfo.getSVGFormat());
               }

            }
            server.removeUser(username);
            chatInfo.setCommand("COMM:PUSH");
            chatInfo.setChatWords("\"" + username + "\" have left!");
            chatInfo.setUsers(users);
            server.sendtoAll(chatInfo);
            in.close();
            out.close();
            incoming.close();
            server.removeConnection(incoming);

//            System.out.println("Game over!");
         }
         catch(IOException e)
         {
            System.out.println("one of the connections has something wrong: " + e);
            server.removeUser(username);
            ChatInfo ci = new ChatInfo("COMM:PUSH", "\"" + username + "\" have left!", null);
//            chatInfo.setCommand("COMM:PUSH");
//            chatInfo.setChatWords("\"" + username + "\" have left!");
            ci.setUsers(users);
            server.sendtoAll(ci);
            server.removeConnection(incoming);
            System.out.println(username + " have left");
         }
         catch(ClassNotFoundException e)
         {
            System.out.println("Class not find: " + e.getMessage() + e);
         }

      }

      /**
      @roseuid 3C7C7E27012E
      */

   }

   public void send(ObjectOutputStream oo, ChatInfo info)
   {
      ObjectOutputStream out = oo;
      try
      {
         out.writeObject(info);
      }
      catch(IOException ie)
      {
         System.out.println("one of the connections has something wrong: " + ie);
      }
   }

   public void sendtoAll(ChatInfo info)
   {
      synchronized( outputStreams )
      {
         // For each client ...
//         for (Enumeration e = outputStreams.elements(); e.hasMoreElements(); )
//            send((ObjectOutputStream)e.nextElement(), info);
         for(Iterator i = outputStreams.values().iterator(); i.hasNext();)
            send((ObjectOutputStream)i.next(), info);
         System.out.println("there are : " +info.getUsers().size());
      }
   }

   public void removeUser(String name)
   {
      users.remove(name);
   }

   public void removeConnection(Socket s)
   {
      synchronized( outputStreams ) {

      // Tell the world
      System.out.println( "Removing connection to "+s );

      // Remove it from our hashtable/list
      outputStreams.remove( s );
      counter--;
      serverFrame.setStatus("Users: " + counter);
      System.out.println("Connecting Clients: " + counter);

      // Make sure it's closed
      try
      {
         s.close();
      }
      catch( IOException ie )
      {
        System.out.println( "Error closing "+s );
        ie.printStackTrace();
      }
      }
   }
}
