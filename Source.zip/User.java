//Source file: e:\\jbuilder4\\jdk1.3\\lib\\User.java


public class User
{
   private String name;
   private String address;
   private String machine;
   private int number;

   public User()
   {
   }

   /**
   @roseuid 3C7668E40074
   */
   public String getUserName()
   {
      return name;
   }

   /**
   @roseuid 3C7668F603A5
   */
   public String getAddress()
   {
      return address;
   }

   /**
   @roseuid 3C7669030282
   */
   public String getMachine()
   {
      return machine;
   }

   /**
   @roseuid 3C7669680092
   */
   public User(String name, String address, String machine)
   {
   }
}
