//Source file: e:\\jbuilder4\\jdk1.3\\lib\\StatusBar.java

import javax.swing.*;
import java.awt.*;

public class StatusBar extends JPanel
{
   private JLabel color;
   private JLabel shapelbl;
   private JLabel mousePosX;
   private JLabel mousePosY;
   private JLabel mode;

   public StatusBar()
   {
      setBackground(Color.lightGray);
      color = new JLabel("Color: ");
      color.setBackground(Color.red);
		color.setPreferredSize(new Dimension(100,14));
      shapelbl = new JLabel("Shape: ");
      shapelbl.setBackground(Color.lightGray);
      shapelbl.setPreferredSize(new Dimension(150,14));
      mousePosX = new JLabel("X: ");
      mousePosX.setBackground(Color.lightGray);
      mousePosX.setPreferredSize(new Dimension(100,14));
      mousePosY = new JLabel("Y: ");
      mousePosY.setBackground(Color.lightGray);
      mousePosY.setPreferredSize(new Dimension(100,14));
      mode = new JLabel("Mode: ");
      mode.setBackground(Color.lightGray);
      mode.setPreferredSize(new Dimension(100,14));

      setLayout(new FlowLayout(FlowLayout.LEFT , 2 , 2));
      add(color);
      add(shapelbl);
      add(mousePosX);
      add(mousePosY);
      add(mode);


   }

   /**
   @roseuid 3C7DF458032A
   */
   public void setColorText(String text, Color c)
   {
      color.setForeground(c);
      color.setText("Color: " + text);
   }

   /**
   @roseuid 3C7DF46902C1
   */
   public void setMousePosX(int x)
   {
      mousePosX.setText("X: " + x);
   }

   /**
   @roseuid 3C7DF47400FA
   */
   public void setMousePosY(int y)
   {
      mousePosY.setText("Y: " + y);
   }

   /**
   @roseuid 3C7DF47B01C2
   */
   public void setModeText(String text)
   {
      color.setText("Mode: " + text);
   }

   public void setShapeText(String text)
   {
      shapelbl.setText("Shape: " + text);
   }

   public void paint(Graphics g)
   {
      super.paint(g);
      g.setColor(Color.darkGray);
      g.drawRect(0, 0, getSize().width - 1, getSize().height - 1);

   }
}
