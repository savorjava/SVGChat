//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGShapeRectangle.java


import java.awt.*;
import java.awt.geom.*;

public class SVGShapeRectangle extends SVGShape
{
   private Rectangle2D.Double rect;

   public SVGShapeRectangle()
   {
      rect = new Rectangle2D.Double(0.0, 0.0, 0, 0);
   }

   /**
   @roseuid 3C766E5600D3
   */
   public void draw(Graphics g)
   {
      super.draw(g);

      rectangle = rect.getBounds();
      Graphics2D g2 = (Graphics2D)g;
      AffineTransform old = g2.getTransform();
      g2.scale(scale, scale);
      g2.setStroke(stroke);
      g2.rotate(angle, Math.abs(((Point2D)positions.get(1)).getX() -
         rect.getWidth() / 2),
         Math.abs(((Point2D)positions.get(1)).getY() -
         rect.getHeight() / 2));
      if(isFill)
      {
         g2.setColor(fillColor);
         g2.fill(rect);
      }
      else
      {
         g2.setColor(drawColor);
         g2.draw(rect);
      }
      g2.setTransform(old);
      generateSVG();
//      System.out.println(SVGFormat);
   }

   public void addPosition(Point2D p2)
   {
         positions.add(p2);
         positions.add(p2);
   }

   public void setPosition(Point2D p2, int address)
   {
      positions.set(address - 1, p2);
      rect.setFrameFromDiagonal((Point2D)positions.get(0),
         (Point2D)positions.get(1));
   }

   public void setSelected(boolean b)
   {
      selected = b;
   }

   public String toString()
   {
      return "Rect:" + rect.getX()+ "," + rect.getY() + " - " +
         rect.width + "," + rect.height;
   }

   public void generateSVG()
   {

      SVGFormat = "<rect x=\"" + rect.getX() + "\" " +
            "y=\"" + rect.getY() + "\" " +
            "width=\"" + rect.width + "\" " +
            "height=\"" + rect.height + "\" " +
            "stroke=\"" +
            (!isFill ? "#" + Integer.toHexString(drawColor.getRGB()).substring(2) : "none") + "\" " +
            "fill=\"" +
            (isFill ? "#" + Integer.toHexString(fillColor.getRGB()).substring(2) : "none") + "\" " +
            "stroke-width=\"" + lineWidth + "\" " +
            "/>";
   }
}
