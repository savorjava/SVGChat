//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGImage.java

import java.util.*;
import java.awt.*;
import java.io.*;

public class SVGImage
{
   private ArrayList vectorShapes = new ArrayList(20);
   private SVGShape vectorShape;
   private String SVGFormat;        /*this SVGFormat is not same as the SVGFormat
                                    in class SVGShape, this one include SVGShapes.*/
   private int selectedShape = 0;
   public SVGShape theSVGShape[];

   public SVGImage()
   {
   }

   /**
   @roseuid 3C7B445A007A
   */
   public String getSVG()
   {
      SVGFormat ="<?xml version = \"1.0\" standalone = \"no\"?> " +
//         "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 20010904//EN\" \"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\"> " +
//         "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 20001102//EN\" \"http://www.w3.org/TR/2000/CR-SVG-20001102/DTD/svg-20001102.dtd\"> " +
         "<svg width=\"13.5cm\" height=\"20.7cm\" viewBox=\"0 0 1350 270\" xmlns=\"http://www.w3.org/2000/svg\"> " +
         "<desc>This SVG made by SVGChat - (savorjava@yahoo.com.cn)</desc> ";
      for(int i = 0; i<vectorShapes.size() ; i++)
         SVGFormat += ((SVGShape)vectorShapes.get(i)).getSVG() + " ";
      return SVGFormat + "</svg>";
   }

   /**
   @roseuid 3C7B453F0305
   */
   public void drawSVG(Graphics g)
   {
      int i = 0;
      SVGShape tempShape;

//      System.out.println(vectorShapes.size() + " is the size of vectorShapes!");
      while(i < vectorShapes.size())
      {
         tempShape = (SVGShape)vectorShapes.get(i++);
         tempShape.draw(g);
      }

   }

   public SVGShapeLine buildLine()
   {
      vectorShape = new SVGShapeLine();
      vectorShapes.add(vectorShape);

      //cancel the last selected shape
      ((SVGShape)vectorShapes.get(selectedShape)).setSelected(false);
      //remember the current shape's address
      selectedShape = vectorShapes.size() - 1;
      vectorShape.setSelected(true);

      return (SVGShapeLine)vectorShape;
   }

   public SVGShapeRectangle buildRect()
   {
      vectorShape = new SVGShapeRectangle();
      vectorShapes.add(vectorShape);

      //cancel the last selected shape
      ((SVGShape)vectorShapes.get(selectedShape)).setSelected(false);
      //remember the current shape's address
      selectedShape = vectorShapes.size() - 1;
      vectorShape.setSelected(true);

      return (SVGShapeRectangle)vectorShape;
   }

   public SVGShapeRoundRectangle buildRound()
   {
      vectorShape = new SVGShapeRoundRectangle();
      vectorShapes.add(vectorShape);

      //cancel the last selected shape
      ((SVGShape)vectorShapes.get(selectedShape)).setSelected(false);
      //remember the current shape's address
      selectedShape = vectorShapes.size() - 1;
      vectorShape.setSelected(true);

      return (SVGShapeRoundRectangle)vectorShape;
   }

   public SVGShapeEllipse buildEllipse()
   {
      vectorShape = new SVGShapeEllipse();
      vectorShapes.add(vectorShape);

      //cancel the last selected shape
      ((SVGShape)vectorShapes.get(selectedShape)).setSelected(false);
      //remember the current shape's address
      selectedShape = vectorShapes.size() - 1;
      vectorShape.setSelected(true);

      return (SVGShapeEllipse)vectorShape;
   }

   public SVGShapeArc buildArc()
   {
      vectorShape = new SVGShapeArc();
      vectorShapes.add(vectorShape);

      //cancel the last selected shape
      ((SVGShape)vectorShapes.get(selectedShape)).setSelected(false);
      //remember the current shape's address
      selectedShape = vectorShapes.size() - 1;
      vectorShape.setSelected(true);

      return (SVGShapeArc)vectorShape;
   }

   public SVGShapeCubicCurve buildCubicCurve()
   {
      vectorShape = new SVGShapeCubicCurve();
      vectorShapes.add(vectorShape);

      //cancel the last selected shape
      ((SVGShape)vectorShapes.get(selectedShape)).setSelected(false);
      //remember the current shape's address
      selectedShape = vectorShapes.size() - 1;
      vectorShape.setSelected(true);

      return (SVGShapeCubicCurve)vectorShape;
   }

   public SVGShapeText buildText()
   {
      vectorShape = new SVGShapeText();
      vectorShapes.add(vectorShape);

      //cancel the last selected shape
      ((SVGShape)vectorShapes.get(selectedShape)).setSelected(false);
      //remember the current shape's address
      selectedShape = vectorShapes.size() - 1;
      vectorShape.setSelected(true);

      return (SVGShapeText)vectorShape;
   }

   public SVGShape getCurrentShape()
   {
      return (SVGShape)vectorShapes.get(selectedShape);
   }

   public void setSelectedShape(int index)
   {
      ((SVGShape)vectorShapes.get(selectedShape)).setSelected(false);
      selectedShape = index;
      ((SVGShape)vectorShapes.get(selectedShape)).setSelected(true);
   }

   public int getSelectedShape()
   {
      return selectedShape;
   }

   //tell SVGPanel how many shapes in the SVGImage
   public int getImageSize()
   {
      return vectorShapes.size();
   }

   public ArrayList getAllShapes()
   {
      return vectorShapes;
   }

   //delete all the shapes in this SVGImage.
   public void clearAll()
   {
      vectorShapes.clear();
   }

   // add a shape from other user or file.
   public void addShape(SVGShape shp)
   {
      vectorShape = shp;
      vectorShapes.add(vectorShape);
   }
}
