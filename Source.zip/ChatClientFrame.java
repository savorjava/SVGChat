//Source file: e:\\jbuilder4\\jdk1.3\\lib\\ChatClientFrame.java

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.lang.*;
import java.net.*;
import java.io.*;
import javax.swing.event.*;
import java.awt.geom.*;

public class ChatClientFrame extends JFrame implements ActionListener
{
   private SVGPanel vectorPanel = new SVGPanel();
   private ControlPanel controlPanel;
   private int width = 640;
   private int height = 480;

   private Container container;
   private SVGChatClient chatClient = null;
   private StatusBar statusBar;
   private JTextArea textArea = new JTextArea();
   private JScrollPane scrollPane = new JScrollPane(textArea,
      JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
      JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
   private ChatClientFrame thisFrame;

   public ChatClientFrame()
   {
//      this("SVG Chat" , null);
   }

   public ChatClientFrame(String title , SVGChatClient cc)
   {
      super(title);
      //get the object of SVGChatClient.
      chatClient = cc;
      controlPanel = new ControlPanel(vectorPanel, cc);
/*
	  	try
      {
	     	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	   }
      catch(Exception exc)
      {
	      System.err.println("Error loading L&F: " + exc);
	   }
*/
      setFont(new Font("Helvetica", Font.PLAIN, 14));
      setSize(width , height);
//      setResizable(false);

      container = getContentPane();
      container.setLayout(new BorderLayout());

      Toolkit toolkit = Toolkit.getDefaultToolkit();
      Dimension screenSize = toolkit.getScreenSize();
      setBounds((screenSize.width - width) / 2 , (screenSize.height -height) / 2 ,
         width , height);

      //place menu, toolbar, status and other elments on the frame.
      init();
   }

   protected void init()
   {
      createMenu();
//      pack();
      setVisible(true);
      thisFrame = this;
   }

   protected void createMenu()
   {
      JMenuBar menuBar = new JMenuBar();
      JMenuItem menuItem;
      JMenu menu = new JMenu("File");
      //create the menu item in File menu.
      Action connectloginAction = new Connect_LoginAction (new ImageIcon("resources/connect.gif"));
      menu.add(connectloginAction);
      Action disconnectAction = new DisconnectAction (new ImageIcon("resources/disconnect.gif"));
      menu.add(disconnectAction);
      menu.addSeparator();
      Action newSVGAction = new newSVGAction(new ImageIcon("resources/new.gif"));
      menu.add(newSVGAction);
      menu.add(new SaveSVGAction(new ImageIcon("resources/save.gif")));
      menu.add(new LoadSVGAction(new ImageIcon("resources/load.gif")));
      //add a separation line
      menu.addSeparator();
      menuItem = new JMenuItem("Exit");
      menuItem.addActionListener(new ExitAction());
      menu.add(menuItem);
      //add File menu into menubar.
      menuBar.add(menu);

      menu = new JMenu("Draw");
      //create the menu item in Draw menu.
      ShapeAction selectAction = new ShapeAction(
         new ImageIcon("resources/select.gif"), "Select", "Select Shape");
      menu.add(selectAction);
      ShapeAction lineAction = new ShapeAction(
         new ImageIcon("resources/line.gif"), "Line", "Draw Line");
      menu.add(lineAction);
      ShapeAction rectangleAction = new ShapeAction(
         new ImageIcon("resources/rectangle.gif"), "Rectangle", "Draw Rectangle");
      menu.add(rectangleAction);
      ShapeAction roundrectangleAction = new ShapeAction(
         new ImageIcon("resources/round.gif"), "RoundRectangle", "Draw Round Rectangle");
      menu.add(roundrectangleAction);
      ShapeAction ellipseAction = new ShapeAction(
         new ImageIcon("resources/Ellipse.gif"), "Ellipse", "Draw Ellipse");
      menu.add(ellipseAction);
      ShapeAction arcAction = new ShapeAction(
         new ImageIcon("resources/arc.gif"), "Arc", "Draw Arc");
      menu.add(arcAction);
      ShapeAction cubiccurveAction = new ShapeAction(
         new ImageIcon("resources/cubiccurve.gif"), "CubicCurve", "Draw Cubic Curve");
      menu.add(cubiccurveAction);
      ShapeAction textAction = new ShapeAction(
         new ImageIcon("resources/text.gif"), "Text", "Draw Text");
      menu.add(textAction);
      //add Draw menu into menubar.
      menuBar.add(menu);

      menu = new JMenu("Color");
      //create the menu item in Color menu.
      menu.add(new ColorAction("Red", null, Color.red));
      menu.add(new ColorAction("Orange", null, Color.orange));
      menu.add(new ColorAction("Yellow", null, Color.yellow));
      menu.add(new ColorAction("Green", null, Color.green));
      menu.add(new ColorAction("Black", null, Color.black));
      menu.add(new ColorAction("Blue", null, Color.blue));
      menu.add(new ColorAction("Magenta", null, Color.magenta));
      menu.add(new ColorAction("Cyan", null, Color.cyan));
      menu.add(new ColorAction("White", null, Color.white));
      menu.add(new ColorAction("Pink", null, Color.pink));
      menu.add(new ColorAction("Lightgray", null, Color.lightGray));
      menu.add(new ColorAction("Gray", null, Color.gray));



      //add a separation line
      menu.addSeparator();
      menu.add(new CustomAction(new ImageIcon("resources/custom.gif")));
      //add Color menu into menubar.
      menuBar.add(menu);

      menu = new JMenu("Tool");
      //create the menu item in Draw menu.
      Action moveAction = new ShapeAction(
         new ImageIcon("resources/Move.gif"), "Move", "Move Shape");
      menu.add(moveAction);
      Action rotateAction = new RotateAction(new ImageIcon("resources/rotate.gif"));
      menu.add(rotateAction);
      menu.add(new ZoomInAction(new ImageIcon("resources/zoomin.gif")));
      menu.add(new ZoomOutAction(new ImageIcon("resources/zoomout.gif")));
      menuItem = new JMenuItem("Up a Layer");
      menuItem.addActionListener(new UpaLayerAction());
      menu.add(menuItem);
      menuItem = new JMenuItem("Down a Layer");
      menuItem.addActionListener(new DownaLayerAction());
      menu.add(menuItem);
      menuItem = new JMenuItem("Top Layer");
      menuItem.addActionListener(new TopLayerAction());
      menu.add(menuItem);
      menuItem = new JMenuItem("Bottom Layer");
      menuItem.addActionListener(new BottomLayerAction());
      menu.add(menuItem);
      Action deleteAction = new DeleteAction(new ImageIcon("resources/delete.gif"));
      menu.addSeparator();
      menu.add(deleteAction);
      //add Tool menu into menubar.
      menuBar.add(menu);

      menu = new JMenu("Help");
      //create the menu item in Draw menu.
      menuItem = new JMenuItem("Snake Run");
      menuItem.addActionListener(new SnakeRunAction());
      menu.add(menuItem);
      menu.addSeparator();
      Action aboutmeAction = new AboutMeAction(new ImageIcon("resources/aboutme.gif"));
      menu.add(aboutmeAction);
      //add Help menu into menubar.
      menuBar.add(menu);

      //place menubar into the frame.
      setJMenuBar(menuBar);

      JToolBar drawBar = new JToolBar(JToolBar.VERTICAL);
      JToolBar sysBar = new JToolBar();
      JButton button;// = new JButton(new Connect_LoginAction(new ImageIcon("resources/connect.gif")));
//      button.setMargin(new Insets(0,0,0,0));
      sysBar.add(new ToolBarButton(connectloginAction));
      sysBar.add(new ToolBarButton(disconnectAction));
      sysBar.addSeparator();
      sysBar.add(new ToolBarButton(newSVGAction));
      sysBar.add(new ToolBarButton((Action)new LoadSVGAction(new ImageIcon("resources/load.gif"))));
      sysBar.add(new ToolBarButton((Action)new SaveSVGAction(new ImageIcon("resources/save.gif"))));

      drawBar.add(new ToolBarButton(selectAction));
      drawBar.add(new ToolBarButton(lineAction));
      drawBar.add(new ToolBarButton(rectangleAction));
      drawBar.add(new ToolBarButton(roundrectangleAction));
      drawBar.add(new ToolBarButton(ellipseAction));
      drawBar.add(new ToolBarButton(arcAction));
      drawBar.add(new ToolBarButton(cubiccurveAction));
      drawBar.add(new ToolBarButton(textAction));
      drawBar.addSeparator();
      drawBar.add(new ToolBarButton((Action)new CustomAction(new ImageIcon("resources/custom.gif"))));
      drawBar.addSeparator();
      drawBar.add(new ToolBarButton(moveAction));
      drawBar.add(new ToolBarButton(rotateAction));
      drawBar.add(new ToolBarButton((Action)new ZoomInAction(new ImageIcon("resources/zoomin.gif"))));
      drawBar.add(new ToolBarButton((Action)new ZoomOutAction(new ImageIcon("resources/zoomout.gif"))));
      drawBar.addSeparator();
      drawBar.add(new ToolBarButton(deleteAction));
      sysBar.addSeparator();
      sysBar.add(new ToolBarButton(aboutmeAction));
      container.add(drawBar, "West");
      container.add(sysBar,"North");
      drawBar.setFloatable(false);
      sysBar.setFloatable(false);


      //place a status bar into the frame.
      statusBar = new StatusBar();
      statusBar.setColorText("Black", vectorPanel.getCurrentColor());
      container.add(statusBar , "South");

      //setup main work area which include canvas, info-windows and control area.
      JPanel mainPanel = new JPanel(new BorderLayout());
      container.add(mainPanel, "Center");
      Dimension mainPanelSize = mainPanel.getSize();


      JPanel drawPanel = new JPanel(new GridLayout(1, 2));

      SVGMouseListener vectorListener = new SVGMouseListener();
      vectorPanel.addMouseListener(vectorListener);
      vectorPanel.addMouseMotionListener(vectorListener);
      drawPanel.add(vectorPanel);
      textArea.setLineWrap(true);
      textArea.setWrapStyleWord(true);
      textArea.setAutoscrolls(true);
      textArea.setBackground(new Color(160,224, 239));
      textArea.setEditable(false);
//      scrollPane.setPreferredSize(new Dimension(281,225));
//      textArea.setSize(200,200);
      drawPanel.add(scrollPane);


      mainPanel.add(drawPanel, "Center");
      mainPanel.add(controlPanel, "South");

      //add current panel into the JComboBox SVGs in controlPanel.
      controlPanel.addImage(vectorPanel.getImage());


   }

   class ToolBarButton extends JButton
   {
      public ToolBarButton(Action a)
      {
         super((Icon)a.getValue(Action.SMALL_ICON));

         String toolTip
            = (String)a.getValue(Action.SHORT_DESCRIPTION);
         if(toolTip == null)
            toolTip = (String)a.getValue(Action.NAME);
         if(toolTip != null)
            setToolTipText(toolTip);
         addActionListener(a);
      }
   }


   class AboutMeAction extends AbstractAction
   {
      public AboutMeAction(Icon icon)
      {
         putValue(Action.NAME, "About Me");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "About Me");
      }

      public void actionPerformed(ActionEvent e)
      {
         JOptionPane.showMessageDialog(vectorPanel.getRootPane().getParent(),
            "- SVG Network CAI System -\n\n\n" +
            "Author: ShaJin\n" +
            "E-mail: savorjava@yahoo.com.cn\n\n" +
            "Copyright: none 2002.3.13\n\n"+
            "Special Thanks: \n"+
            "My father, my mother, my sister and their love,\n" +
            "they let me understand what's the true love.\n",
            "About this program...", JOptionPane.INFORMATION_MESSAGE );
//         System.out.println("you have choosed menu item About Me!");
      }
   }

   class SnakeRunAction extends AbstractAction
   {
      public SnakeRunAction()
      {
         super("Snake Run");
      }

      public void actionPerformed(ActionEvent e)
      {

         try
         {
            Class sr =
//               ClassLoader.getSystemClassLoader().loadClass("SnakeRun.class");
               Class.forName("SnakeRun");
            SnakeRun snake = (SnakeRun)sr.newInstance();
            String args[]={"",""};
            snake.main(args);
//            System.out.println("Snake is running");
         }
         catch(ClassNotFoundException cnfe){System.out.println("No class");}
         catch(IllegalAccessException iae){System.out.println("IA");}
         catch(InstantiationException ie){System.out.println("IE");}
//         System.out.println("you have choosed menu item Snake Run!");
      }
   }

   class MoveAction extends AbstractAction
   {
      public MoveAction(Icon icon)
      {
         putValue(Action.NAME, "Move");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Move Shape");
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item Move!");
      }
   }

   class RotateAction extends AbstractAction
   {
      public RotateAction(Icon icon)
      {
         putValue(Action.NAME, "Rotate");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Rotate Shape");
      }

      public void actionPerformed(ActionEvent e)
      {
         if(!vectorPanel.isEmpty())
         {
            double angle = controlPanel.getAngle() * Math.PI / 180;
            vectorPanel.getShape().setAngle(angle);
            vectorPanel.repaint();
         }
//         System.out.println("you have choosed menu item Rotate!");
      }
   }

   class ZoomInAction extends AbstractAction
   {
      public ZoomInAction(Icon icon)
      {
         putValue(Action.NAME, "Zoom in");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Zoom in");
      }

      public void actionPerformed(ActionEvent e)
      {
         if(!vectorPanel.isEmpty())
         {
            vectorPanel.getShape().addScale(0.1);
            vectorPanel.repaint();
         }
//         System.out.println("you have choosed menu item ZoomIn!");
      }
   }

   class ZoomOutAction extends AbstractAction
   {
      public ZoomOutAction(Icon icon)
      {
         putValue(Action.NAME, "Zoom out");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Zoom out");
      }

      public void actionPerformed(ActionEvent e)
      {
         if(!vectorPanel.isEmpty())
         {
            vectorPanel.getShape().addScale(-0.1);
            vectorPanel.repaint();
         }
//         System.out.println("you have choosed menu item ZoomOut!");
      }
   }

   class UpaLayerAction extends AbstractAction
   {
      public UpaLayerAction()
      {
         super("UpaLayer");
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item UpaLayer!");
      }
   }

   class DownaLayerAction extends AbstractAction
   {
      public DownaLayerAction()
      {
         super("DownaLayer");
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item DownaLayer!");
      }
   }

   class TopLayerAction extends AbstractAction
   {
      public TopLayerAction()
      {
         super("TopLayer");
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item TopLayer!");
      }
   }

   class BottomLayerAction extends AbstractAction
   {
      public BottomLayerAction()
      {
         super("BottomLayer");
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item BottomLayer!");
      }
   }

   class CustomAction extends AbstractAction
   {
      public CustomAction(Icon icon)
      {
         putValue(Action.NAME, "Custom...");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Custom Color");
      }

      public void actionPerformed(ActionEvent e)
      {
         Color newColor = JColorChooser.showDialog(thisFrame,
            "Select your favorite color", Color.black);
         Color oldcolor = vectorPanel.getCurrentColor();
         System.out.println("you have choosed menu item Custom!");
         if(newColor!=null)
         {
            statusBar.setColorText((String)getValue(Action.NAME) ,
               newColor);
            vectorPanel.setCurrentColor(newColor);
         }
      }
   }


   class ShapeAction extends AbstractAction
   {
      String shapeName;

      public ShapeAction(Icon icon, String name, String desc)
      {
         putValue(Action.NAME, name);
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, desc);

         shapeName = name;
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item " + shapeName);
         vectorPanel.setCurrentShape(shapeName);
         statusBar.setShapeText(shapeName);
      }
   }

   class TextAction extends AbstractAction
   {
      public TextAction(Icon icon)
      {
         putValue(Action.NAME, "Text");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Draw Text");
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item Text!");
      }
   }

   class ExitAction extends AbstractAction
   {
      public ExitAction()
      {
         super("Exit");
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item Exit!");
         chatClient.setClientModeoff();
         System.exit(0);
      }
   }

   class LoadSVGAction extends AbstractAction
   {
      public LoadSVGAction(Icon icon)
      {
         putValue(Action.NAME, "Load");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Load SVG");
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item Load SVG!");
         addImage(new SVGParser(vectorPanel).parserInit(vectorPanel.loadFile()));
      }
   }

   class SaveSVGAction extends AbstractAction
   {
      public SaveSVGAction(Icon icon)
      {
         putValue(Action.NAME, "Save");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Save SVG");
      }

      public void actionPerformed(ActionEvent e)
      {
         System.out.println("you have choosed menu item Save SVG!");
         vectorPanel.saveFile();
      }
   }

   class newSVGAction extends AbstractAction
   {
      public newSVGAction(Icon icon)
      {
         putValue(Action.NAME, "New");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "New SVG");
      }

      public void actionPerformed(ActionEvent e)
      {
         if(!vectorPanel.checkSaved())
         {
            int n = JOptionPane.showOptionDialog(thisFrame,
                "You have modified current file ! \n"
                + "Do you want to save it ?",
                "Saving you file...",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null, null, null);
            if(n == 0)
            {
               if(vectorPanel.saveFile())
               {
                  vectorPanel.newFile();
                  controlPanel.addImage(vectorPanel.getImage());
               }
            }
            else if(n == 1)
            {
               vectorPanel.newFile();
               controlPanel.addImage(vectorPanel.getImage());
            }
         }
         vectorPanel.repaint();


         System.out.println("you have choosed menu item New SVG!");
      }
   }

   class Connect_LoginAction extends AbstractAction
   {
      public Connect_LoginAction(Icon icon)
      {
         putValue(Action.NAME, "Connect & Login");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Connect & Login");
      }

      public void actionPerformed(ActionEvent e)
      {
         LoginDialog connectDlg = new LoginDialog(thisFrame, "Connect and Login ...", true);

         //place the dialog to the center of the screen.
         Toolkit toolkit = Toolkit.getDefaultToolkit();
         Dimension screenSize = toolkit.getScreenSize();
         connectDlg.setBounds((screenSize.width - connectDlg.getSize().width) / 2 ,
            (screenSize.height -connectDlg.getSize().height) / 2 ,
            connectDlg.getSize().width , connectDlg.getSize().height);
         connectDlg.setVisible(true);

         System.out.println("you have choosed menu item Connect_Login!");
      }
   }

      class LoginDialog extends JDialog
      {
         private JTextField hostTfd = new JTextField(chatClient.getHost(), 20);
         private JTextField portTfd = new JTextField(chatClient.getPort() + "", 5);
         private JTextField nameTfd = new JTextField("Vector", 20);
         private JPanel hostPanel = new JPanel(new GridLayout(1, 2));
         private JPanel portPanel = new JPanel(new GridLayout(1, 2));
         private JPanel namePanel = new JPanel(new GridLayout(1, 2));
         private JPanel controlPanel = new JPanel(new GridLayout(1, 2));

         public LoginDialog()
         {
         }

         public LoginDialog(ChatClientFrame frame, String s , boolean m)
         {
            super(frame, s, m);
            Container c = getContentPane();
            setSize(320, 240);
            c.setLayout(new GridLayout(6,1 ));
            c.add(new JLabel("Welcome! Please input the following information!",
               JLabel.RIGHT));
            hostPanel.add(new JLabel("Host: "));
            hostPanel.add(hostTfd);
            portPanel.add(new JLabel("Port: "));
            portPanel.add(portTfd);
            namePanel.add(new JLabel("Username: "));
            namePanel.add(nameTfd);
            c.add(hostPanel);
            c.add(portPanel);
            c.add(namePanel);
            c.add(new JLabel("Notice: The default port of server is 4321"));
            controlPanel.add(new JButton(new LoginAction(this)));
            controlPanel.add(new JButton(new CancelAction(this)));
            c.add(controlPanel);
         }

         public String getHost()
         {
            return hostTfd.getText();
         }

         public int getPort()
         {
            return Integer.parseInt(portTfd.getText());
         }

         public String getName()
         {
            return nameTfd.getText();
         }
      }



   class LoginAction extends AbstractAction
   {
      public LoginAction(JDialog dlg)
      {
         super("Login");
         putValue("Dialog", dlg);
      }

      public void actionPerformed(ActionEvent evt)
      {
         LoginDialog dialog;
         System.out.println("you have choosed button Login!");
         dialog = (LoginDialog)getValue("Dialog");
         if(chatClient.getClientMode().equals("online"))
         {
            JOptionPane.showMessageDialog(dialog, "Hi, " + dialog.getName() +
               ", you are connecting to " +
               dialog.getHost() + ":" + dialog.getPort() +
               ".\n if you wanna get a new connection, please disconnect first!",
               "Are you sure...", JOptionPane.ERROR_MESSAGE);
         }
         else
         {
            System.out.println("you have input: " + dialog.nameTfd.getText()+"("+dialog.nameTfd.getText().length()+")");
            if(dialog.nameTfd.getText().length() == 0)
            {
               dialog.nameTfd.setText("input name");
            }
            else
            {
               chatClient.login(dialog);
               System.out.println("I am in Dialog!");
               controlPanel.setChatFocus();
               dialog.dispose();
            }
         }

      }

   }

   class CancelAction extends AbstractAction
   {
      public CancelAction(JDialog dlg)
      {
         super("Cancel");
         putValue("Dialog", dlg);
      }

      public void actionPerformed(ActionEvent evt)
      {
         LoginDialog dialog;
         System.out.println("you have choosed button Cancel!");
         dialog = (LoginDialog)getValue("Dialog");
         dialog.dispose();
      }
   }


   class DisconnectAction extends AbstractAction
   {
      public DisconnectAction(Icon icon)
      {
         putValue(Action.NAME, "Disconnect");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Disconnet");
      }

      public void actionPerformed(ActionEvent e)
      {
         if(chatClient.getClientMode().equals("online"))
         {
            controlPanel.setUsers(new ArrayList(0));
            chatClient.setOff();
            clearInfo();
            printInfo("You have cut off the connection with server!!!");
         }
         System.out.println("you have choosed menu item Disconnect!");
      }
   }

   class ColorAction extends AbstractAction
   {
      public ColorAction(String name, Icon icon, Color c)
      {
         putValue(Action.NAME, name);
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, name);
         putValue("Color", c);
      }

      public void actionPerformed(ActionEvent evt)
      {
         System.out.println("you have choosed menu item " + getValue(Action.NAME));
         statusBar.setColorText((String)getValue(Action.NAME) ,
            (Color)getValue("Color"));
         vectorPanel.setCurrentColor((Color)getValue("Color"));
      }
   }

   class DeleteAction extends AbstractAction
   {
      public DeleteAction(Icon icon)
      {
         putValue(Action.NAME, "Delete");
         putValue(Action.SMALL_ICON, icon);
         putValue(Action.SHORT_DESCRIPTION, "Delete Shape");
      }

      public void actionPerformed(ActionEvent evt)
      {
         if(!vectorPanel.isEmpty())
         {
            ArrayList al = vectorPanel.getAllShapes();
            int index = vectorPanel.getSelectedShape();
            controlPanel.deleteShape(index);
            al.remove(index);
            if(index > 0)
               vectorPanel.setSelectedShape(0);
//            if(index > 0)
  //          {
    //           vectorPanel.setSelectedShape(0);
      //         controlPanel.setSelectedShape(0);
        //    }
            System.out.println("I am deleting shape " + index);

            vectorPanel.repaint();

         }
      }
   }

   /*printInfo and clearInfo is called by SVGChatClient for show chatting or
   system infomation*/
   public void printInfo(String s)
   {
//      textArea.append(s);
      textArea.insert(s, 0);
   }

   public void clearInfo()
   {
      textArea.setText("");
   }

   public void drawImage(SVGImage img)
   {
      controlPanel.addImage(img);
   }

   public void setUsers(ArrayList us)
   {
      controlPanel.setUsers(us);
      System.out.println("There are : " + us.size());
   }

   public void addImage(SVGImage img)
   {
      controlPanel.addImage(img);
      controlPanel.setAllShapes();
   }


   public void actionPerformed(ActionEvent e)
   {



   }

   class SVGMouseListener extends MouseInputAdapter
   {
      SVGShape shape = null;
      int selectedPos = -1;
      int startX = 0, startY = 0;

      public void mouseMoved(MouseEvent e)
      {

         statusBar.setMousePosX(e.getX());
         statusBar.setMousePosY(e.getY());
//         System.out.println(e.getX() + "  " + e.getY());
         if(vectorPanel.getCurrentShape().equals("Select"))
         {
            Point p = e.getPoint();
            ArrayList shapes = vectorPanel.getAllShapes();
            for(int i = 0; i < shapes.size(); i++)
            {
               if(((SVGShape)shapes.get(i)).rectangle.contains(p))
               {
                  vectorPanel.setSelectedShape(i);
                  vectorPanel.repaint();
               }
            }
         }

      }

      public void mouseDragged(MouseEvent e)
      {
         if(vectorPanel.getCurrentShape().equals("Line") ||
            vectorPanel.getCurrentShape().equals("Rectangle")||
            vectorPanel.getCurrentShape().equals("RoundRectangle")||
            vectorPanel.getCurrentShape().equals("Ellipse")||
            vectorPanel.getCurrentShape().equals("Arc")||
            vectorPanel.getCurrentShape().equals("CubicCurve")||
            vectorPanel.getCurrentShape().equals("Text"))
         {
//            System.out.println("you have dragged mouse!");
//            shape = vectorPanel.getNewShape();
            //click 2 is for end of the line
            shape.setPosition(new Point2D.Double(e.getX(), e.getY()), 2);

            controlPanel.setEndPos(e.getX() + " , " + e.getY());
            controlPanel.setWidth((int)Math.abs(
               shape.getPosition(1).getX() - shape.getPosition(2).getX()));
            controlPanel.setHeight((int)Math.abs(
               shape.getPosition(1).getY() - shape.getPosition(2).getY()));
         }
         else
         if(vectorPanel.getCurrentShape().equals("Select"))
         {
            if(!vectorPanel.isEmpty())
            {
               if(selectedPos >= 0)
               {
                  Point p = e.getPoint();
                  shape.setPosition(new Point2D.Double(p.getX(), p.getY()),
                     selectedPos + 1);
               }
               else
               {
               int lastX = startX, lastY = startY;
               Point p = e.getPoint();
               Point2D p2;
               ArrayList al = shape.getPosition();
               for(int i = 0; i < al.size(); i++)
               {
                  p2 = (Point2D)al.get(i);
                  p2.setLocation(p2.getX() + (p.getX() - lastX),
                     p2.getY() + (p.getY() - lastY));
                  startX = e.getX();
                  startY = e.getY();
                  shape.setPosition(p2, i + 1);
               }
               }
            }
         }
         else
         if(vectorPanel.getCurrentShape().equals("Move"))
         {
            if(!vectorPanel.isEmpty())
            {
               int lastX = startX, lastY = startY;
               Point p = e.getPoint();
               Point2D p2;
               ArrayList al = shape.getPosition();
               for(int i = 0; i < al.size(); i++)
               {
                  p2 = (Point2D)al.get(i);
                  p2.setLocation(p2.getX() + (p.getX() - lastX),
                     p2.getY() + (p.getY() - lastY));
                  startX = e.getX();
                  startY = e.getY();
                  shape.setPosition(p2, i + 1);
               }
            }
         }

         if(!vectorPanel.isEmpty())
         {
//         controlPanel.setStartPos(e.getX() + " , " + e.getY());
            controlPanel.setStartPos(shape.getPosition(1).getX() +
               " , " + shape.getPosition(1).getY());
            controlPanel.setEndPos(shape.getPosition(2).getX() +
               " , " + shape.getPosition(2).getY());
            controlPanel.setWidth((int)Math.abs(
               shape.getPosition(1).getX() - shape.getPosition(2).getX()));
            controlPanel.setHeight((int)Math.abs(
               shape.getPosition(1).getY() - shape.getPosition(2).getY()));
         }
         statusBar.setMousePosX(e.getX());
         statusBar.setMousePosY(e.getY());
         vectorPanel.repaint();

      }


      public void mousePressed(MouseEvent e)
      {
         if(vectorPanel.getCurrentShape().equals("Line") ||
            vectorPanel.getCurrentShape().equals("Rectangle")||
            vectorPanel.getCurrentShape().equals("RoundRectangle")||
            vectorPanel.getCurrentShape().equals("Ellipse")||
            vectorPanel.getCurrentShape().equals("Arc")||
            vectorPanel.getCurrentShape().equals("CubicCurve")||
            vectorPanel.getCurrentShape().equals("Text"))
         {
            shape = vectorPanel.getNewShape();
            if(controlPanel.getFill()) //isFill() is better than getFill.
               shape.setFill(true);
            System.out.println("you have pressed mouse!" + e.getX() + "," + e.getY());
            //click 1 is begin of line.
            shape.addPosition(new Point2D.Double(e.getX(), e.getY()));

            shape.drawColor = vectorPanel.getCurrentColor();
            controlPanel.setStartPos(e.getX() + " , " + e.getY());
            controlPanel.setEndPos(e.getX() + " , " + e.getY());
            controlPanel.setLineWidth(shape.lineWidth);
            controlPanel.addShape(shape);
         }
         else
         if(vectorPanel.getCurrentShape().equals("Select"))
         {
            if(!vectorPanel.isEmpty())
            {
               Point p = e.getPoint();
               startX = e.getX();
               startY = e.getY();
               shape = (SVGShape)vectorPanel.getShape();
               ArrayList al = shape.getPosition();
               for(int i = 0; i < al.size(); i++)
               {
                  double x = ((Point2D)al.get(i)).getX() - shape.SIZE / 2;
                  double y = ((Point2D)al.get(i)).getY() - shape.SIZE / 2;
                  Rectangle2D r = new Rectangle2D.Double(x, y, shape.SIZE, shape.SIZE);
                  if(r.contains(p))
                  {
                     selectedPos = i;
                     return;
                  }
               }

            }
         }
         else
         if(vectorPanel.getCurrentShape().equals("Move"))
         {
            if(!vectorPanel.isEmpty())
            {
               shape = (SVGShape)vectorPanel.getShape();
               startX = e.getX();
               startY = e.getY();
            }
         }

         vectorPanel.repaint();
      }

      public void mouseReleased(MouseEvent e)
      {
         selectedPos = -1;
      }

   }
}
