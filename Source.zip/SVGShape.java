//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGShape.java

import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.io.*;

public abstract class SVGShape
{
   protected ArrayList positions = new ArrayList(2);
   protected Point2D.Double Pos = new Point2D.Double(0.0, 0.0);
   protected double scale = 1.0;
   protected int lineWidth = 1;
   protected double angle = 0;
   protected String lineStyle = "";
   protected String SVGFormat = "";
   protected Color drawColor = Color.black;
   protected Color fillColor = Color.white;
   protected static int SIZE = 10;  //the rect on the points of seleted shape
   protected boolean selected = true;
   protected BasicStroke stroke;
   protected int cap = BasicStroke.CAP_BUTT;
   protected int join = BasicStroke.JOIN_BEVEL;
   protected boolean isFill = false;
   protected Rectangle2D rectangle;

   public SVGShape()
   {
      stroke = new BasicStroke(lineWidth, cap, join);
   }

   /**
   @roseuid 3C7667AB036D
   */
   public Point2D.Double getCenterPos()
   {
      return null;
   }

   /**
   @roseuid 3C79071A036A
   */
   public void move()
   {

   }

   /**
   @roseuid 3C7A5529020C
   */
   public void rotate()
   {
   }

   /**
   @roseuid 3C7A554A01D8
   */
   public void transform()
   {
   }

   /**
   @roseuid 3C7A56A1039D
   */
   public void changeScale()
   {
   }

   /**
   @roseuid 3C7B434701DD
   */
   public void generateSVG()
   {
   }

   /**
   @roseuid 3C7B43890279
   */
   public String getSVG()
   {
      return SVGFormat;
   }

   /**
   @roseuid 3C7B5D39002F
   */
   public double getScale()
   {
      return scale;
   }

   /**
   @roseuid 3C7B5D4E0058
   */
   public void setScale(double s)
   {
      scale = s;
   }

   public void addScale(double s)
   {
      scale += s;
   }

   /**
   @roseuid 3C7B5D5602EE
   */
   public int getLineWidth()
   {
      return lineWidth;
   }

   /**
   @roseuid 3C7B5D7600AF
   */
   public String getLineStyle()
   {
      return lineStyle;
   }

   /**
   @roseuid 3C7B5D880033
   */
   public void setLineWidth()
   {
   }

   /**
   @roseuid 3C7B5D9102F3
   */
   public void setLineStyle()
   {
   }

   public void draw(Graphics g)
   {
      Graphics2D g2 = (Graphics2D)g;


      g2.setStroke(new BasicStroke(1, cap, join));
      g2.setColor(drawColor);
      if(selected)
         for(int i = 0; i < positions.size(); i++)
         {
            double x = ((Point2D)positions.get(i)).getX() - SIZE / 2;
            double y = ((Point2D)positions.get(i)).getY() - SIZE / 2;
            Rectangle2D r = new Rectangle2D.Double(x, y, SIZE, SIZE);
            g2.draw(r);
         }

   }

   //modify a position of point in arraylist
   public void setPosition(Point2D p2, int address)
   {
   }

   //add a position of point in arraylist
   public void addPosition(Point2D p2)
   {
   }

   //get the point with special address
   public ArrayList getPosition()
   {
      return positions;
   }

   public Point2D getPosition(int pos)
   {
      return (Point2D)(positions.get(pos - 1));
   }

   //set mine to be a selected shape
   public void setSelected(boolean b)
   {
      selected = b;
   }

   public String toString()
   {
      return "Abstract SVGShape!";
   }

   //set the style of line
   public void setStyle(String s)
   {
      if(s.equals("CAP BUTT"))
         cap = BasicStroke.CAP_BUTT;
      else if(s.equals("CAP ROUND"))
         cap = BasicStroke.CAP_ROUND;
      else if(s.equals("CAP SQUARE"))
         cap = BasicStroke.CAP_SQUARE;
      else if(s.equals("JOIN BEVEL"))
         join = BasicStroke.JOIN_BEVEL;
      else if(s.equals("JOIN MITER"))
         join = BasicStroke.JOIN_MITER;
      else if(s.equals("JOIN ROUND"))
         join = BasicStroke.JOIN_ROUND;
      stroke = new BasicStroke(lineWidth, cap, join);
   }

   public void setLineWidth(int w)
   {
      lineWidth = w;
      stroke = new BasicStroke(lineWidth, cap, join);

   }

   public void setFill(boolean f)
   {
      isFill = f;
   }

   public void setAngle(double ag)
   {
      angle = ag;
   }

}
