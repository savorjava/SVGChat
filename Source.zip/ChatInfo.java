//Source file: e:\\jbuilder4\\jdk1.3\\lib\\ChatInfo.java

import java.util.*;
import java.io.*;

public class ChatInfo implements Serializable
{
   private String command;
   private ArrayList users = null;
   private String chatWords;
   private String SVGFormat;

   public ChatInfo()
   {
   }

   public ChatInfo(String c, String cw, String svg)
   {
      command = c;
      chatWords = cw;
      SVGFormat = svg;
   }



   public void setCommand(String c)
   {
      command = c;
   }

   public String getCommand()
   {
      return command;
   }

   public void setChatWords(String cw)
   {
      chatWords = cw;
   }

   public String getChatWords()
   {
      return chatWords;
   }

   public void setSVGFormat(String svg)
   {
      SVGFormat = svg;
   }

   public String getSVGFormat()
   {
      return SVGFormat;
   }

   public void setUsers(ArrayList u)
   {
      users = u;
   }

   public ArrayList getUsers()
   {
      return users;
   }


}
