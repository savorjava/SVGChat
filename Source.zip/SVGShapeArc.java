//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGShapeArc.java

import java.awt.*;
import java.awt.geom.*;

public class SVGShapeArc extends SVGShape
{
   private Arc2D.Double arc;
   private int startAngle = 0,
      arcAngle = 200,
      closureType = Arc2D.Double.OPEN;

   public SVGShapeArc()
   {
      arc = new Arc2D.Double(0, 0, 0, 0, startAngle, arcAngle, closureType);
   }

   /**
   @roseuid 3C766E57026F
   */
   public void draw(Graphics g)
   {
      super.draw(g);

      rectangle = arc.getBounds();
      arc.start = startAngle;
      arc.extent = arcAngle;
      arc.setArcType(closureType);
      Graphics2D g2 = (Graphics2D)g;
      AffineTransform old = g2.getTransform();
      g2.rotate(angle, Math.abs(((Point2D)positions.get(1)).getX() -
         arc.getWidth() / 2),
         Math.abs(((Point2D)positions.get(1)).getY() -
         arc.getHeight() / 2));
      g2.scale(scale, scale);
      g2.setStroke(stroke);
//         System.out.println("Scale: " + scale);
      if(isFill)
      {
         g2.setColor(fillColor);
         g2.fill(arc);
      }
      else
      {
         g2.setColor(drawColor);
         g2.draw(arc);
      }
//      Arc2D.Double a = new Arc2D.Double(0,0,30,30,0,0,0);
//      a.setAngles(99,94,40,103);
//      g2.draw(a);
      g2.setTransform(old);
      generateSVG();
//      System.out.println(SVGFormat);
//      System.out.println(arc.getEndPoint().getX()+","+arc.getEndPoint().getY());

   }

   public void addPosition(Point2D p2)
   {
         positions.add(p2);
         positions.add(p2);
   }

   public void setPosition(Point2D p2, int address)
   {
      positions.set(address - 1, p2);
      arc.setFrameFromDiagonal((Point2D)positions.get(0),
         (Point2D)positions.get(1));
   }

   public void setSelected(boolean b)
   {
      selected = b;
   }

   public String toString()
   {
      return "Arc:" + arc.getX()+ "," + arc.getY() + " - " +
         arc.width + "," + arc.height;
   }

   public void setStartAngle(int sa)
   {
      startAngle = sa;
   }

   public void setArcAngle(int aa)
   {
      arcAngle = aa;
   }

   public int getArcAngle()
   {
      return arcAngle;
   }

   public int getStartAngle()
   {
      return startAngle;
   }

   public int getClosureType()
   {
      return closureType;
   }

   public void setClosureType(int ct)
   {
      closureType = ct;
   }

// draw a arc from SVG file is difficult, so I place J2D paras of arc in color part.
   public void generateSVG()
   {
      String x = "" + (int)(Math.abs(((Point2D)positions.get(0)).getX()));
      String y = "" + (int)(Math.abs(((Point2D)positions.get(0)).getY()));
      String sa = "" + (startAngle < 0 ? 360 - startAngle : startAngle);
      String ea = "" + (arcAngle < 0 ? 360 - arcAngle : arcAngle);

      if(x.length() < 2)
         x = "00" + x;
      else if(x.length() < 3)
         x = "0" + x;
      if(y.length() < 2)
         y = "00" + y;
      else if(y.length() < 3)
         y = "0" + y;

      if(sa.length() < 2)
         sa = "00" + sa;
      else if(sa.length() < 3)
         sa = "0" + sa;
      if(ea.length() < 2)
         ea = "00" + ea;
      else if(y.length() < 3)
         ea = "0" + ea;

      SVGFormat = "<path d=\"M" + arc.getStartPoint().getX() + "," +
         arc.getStartPoint().getY() +
         " a" + (arc.width / 2) + "," + (arc.height / 2) +
         (arcAngle <= 180 ? " 0 0,0 " : " 0 1,0 ") +
         (arc.getEndPoint().getX() - arc.getStartPoint().getX()) + "," +
         (arc.getEndPoint().getY() - arc.getStartPoint().getY())+ " z\" " +
         "stroke=\"" +
// use coordinates of first position of rectangle of arc instead of draw color
//         (!isFill ? "#" + Integer.toHexString(drawColor.getRGB()).substring(2) : "none") + "\" " +
         "#" + x + y +  "\" " +
         "fill=\"" +
// use start angle and extend angle of arc instead of fill color
//         (isFill ? "#" + Integer.toHexString(fillColor.getRGB()).substring(2) : "none") + "\" " +
         "#" + sa + ea +  "\" " +
         "stroke-width=\"" + lineWidth + "\" " +
         "/>";
   }
}
