//Source file: e:\\jbuilder4\\jdk1.3\\lib\\ChatLog.java

import java.io.*;
import java.util.*;

public class ChatLog
{
   private ArrayList logInfos;
   private String logInfo;
   private File logFile;
   private OutputStream logOutput;

   /**
   @roseuid 3C790DFA02DE
   */
   public ChatLog()
   {
   }

   /**
   @roseuid 3C790D9601C2
   */
   public void setLogInfo()
   {
   }

   /**
   @roseuid 3C790DDE0266
   */
   public void writeLogFile()
   {
   }
}
