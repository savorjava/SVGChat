//Source file: e:\\jbuilder4\\jdk1.3\\lib\\ChatServerFrame.java

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

public class ChatServerFrame extends JFrame
{
   private int width;
   private int height;
   private JButton controlBtn = new JButton("Stop All Clients");
   private JButton exitBtn = new JButton("Close Server");
   private JLabel userNumberLbl = new JLabel("Users: 0", JLabel.CENTER);

   public ChatLog theChatLog;

   public ChatServerFrame(String title, SVGChatServer server)
   {
      super(title);
      width = 250;
      height = 300;
      Toolkit toolkit = Toolkit.getDefaultToolkit();
      Dimension screenSize = toolkit.getScreenSize();
      setBounds((screenSize.width - width) / 2 , (screenSize.height -height) / 2 ,
         width , height);
      Container container = getContentPane();
      container.setLayout(new GridLayout(3, 1));
      controlBtn.addActionListener(server);
      exitBtn.addActionListener(server);
      container.add(controlBtn);
      container.add(exitBtn);
      container.add(userNumberLbl);

      addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            System.out.println("Closing frame!");
            System.exit(0);
         }
      });
   }

   public void setStatus(String status)
   {
      userNumberLbl.setText(status);
   }
}
