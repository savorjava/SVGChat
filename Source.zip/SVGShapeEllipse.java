//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGShapeEllipse.java

import java.awt.*;
import java.awt.geom.*;

public class SVGShapeEllipse extends SVGShape
{
   Ellipse2D.Double ellipse;

   public SVGShapeEllipse()
   {
      ellipse = new Ellipse2D.Double(0, 0, 0, 0);
   }

   /**
   @roseuid 3C766E5D02FA
   */
   public void draw(Graphics g)
   {
      super.draw(g);

      rectangle = ellipse.getBounds();
      Graphics2D g2 = (Graphics2D)g;
      AffineTransform old = g2.getTransform();
      g2.scale(scale, scale);
      g2.rotate(angle, Math.abs(((Point2D)positions.get(1)).getX() -
         ellipse.getWidth() / 2),
         Math.abs(((Point2D)positions.get(1)).getY() -
         ellipse.getHeight() / 2));
      g2.setStroke(stroke);
      if(isFill)
      {
         g2.setColor(fillColor);
         g2.fill(ellipse);
      }
      else
      {
         g2.setColor(drawColor);
         g2.draw(ellipse);
      }
      g2.setTransform(old);
      generateSVG();
//      System.out.println(SVGFormat);
   }

   public void addPosition(Point2D p2)
   {
         positions.add(p2);
         positions.add(p2);
   }

   public void setPosition(Point2D p2, int address)
   {
      positions.set(address - 1, p2);
      ellipse.setFrameFromDiagonal((Point2D)positions.get(0),
         (Point2D)positions.get(1));
   }

   public void setSelected(boolean b)
   {
      selected = b;
   }

   public String toString()
   {
      return "Ellipse:" + ellipse.getX()+ "," + ellipse.getY() + " - " +
         ellipse.width + "," + ellipse.height;
   }

   public void generateSVG()
   {
      if(ellipse.width != ellipse.height)
         SVGFormat = "<ellipse cx=\"" + (ellipse.getX() + ellipse.width / 2) + "\" " +
            "cy=\"" + (ellipse.getY() + ellipse.height / 2) + "\" " +
            "rx=\"" + ellipse.width / 2 + "\" " +
            "ry=\"" + ellipse.height / 2 + "\" " +
            "stroke=\"" +
            (!isFill ? "#" + Integer.toHexString(drawColor.getRGB()).substring(2) : "none") + "\" " +
            "fill=\"" +
            (isFill ? "#" + Integer.toHexString(fillColor.getRGB()).substring(2) : "none") + "\" " +
            "stroke-width=\"" + lineWidth + "\" " +
            "/>";
      else
         SVGFormat = "<circle cx=\"" + (ellipse.getX() + ellipse.width ) + "\" " +
            "cy=\"" + (ellipse.getY() - ellipse.height ) + "\" " +
            "r=\"" + ellipse.width + "\" " +
            "stroke=\"" +
            (!isFill ? "#" + Integer.toHexString(drawColor.getRGB()).substring(2) : "none") + "\" " +
            "fill=\"" +
            (isFill ? "#" + Integer.toHexString(fillColor.getRGB()).substring(2) : "none") + "\" " +
            "stroke-width=\"" + lineWidth + "\" " +
            "/>";
   }
}
