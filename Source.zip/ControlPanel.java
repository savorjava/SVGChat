//Source file: e:\\jbuilder4\\jdk1.3\\lib\\ControlPanel.java

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.*;

public class ControlPanel extends JPanel
{
   private JTextField myWords = new JTextField(250);
   private JButton sendText = new JButton("Sent text");
   private JButton sendTextSVG = new JButton("Send text & SVG");
   private ButtonGroup sentTo = new ButtonGroup();
   private JRadioButton toOne = new JRadioButton("Send to one");
   private JRadioButton toAll = new JRadioButton("Send to all");
   private JComboBox userList = new JComboBox();
   private JTextField shapeStartPos = new JTextField(11);
   private JTextField shapeEndPos = new JTextField(11);
   private JTextField shapeWidth = new JTextField(4);
   private JTextField shapeHeight = new JTextField(4);
   private JTextField shapeAngle = new JTextField(4);
   private JTextField shapeLineWidth = new JTextField(4);
   private JCheckBox filling = new JCheckBox("Filling");
   private JComboBox shapeLineStyle = new JComboBox();
   private JComboBox SVGs = new JComboBox();
   private JComboBox SVGShapes = new JComboBox();
   private ButtonGroup userModes = new ButtonGroup();
   private JRadioButton chatMode = new JRadioButton("Chat mode");
   private JRadioButton drawMode = new JRadioButton("Draw mode");
   private JButton drawColorButton = new JButton("Draw Color");
   private JButton fillColorButton = new JButton("Fill Color");
   private JButton activateBtn = new JButton("Activate");

   private SVGChatClient chatClient;

   private SVGPanel vectorPanel;

   private SVGParser svgParser;


   public ControlPanel(SVGPanel vp, SVGChatClient client)
   {
/*
	  	try
      {
	     	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	   }
      catch(Exception exc)
      {
	      System.err.println("Error loading L&F: " + exc);
	   }
*/
      vectorPanel = vp;
      chatClient = client;
      svgParser = new SVGParser(vp);
      chatClient.setSVGParser(svgParser);

      GridBagLayout gridBag = new GridBagLayout();
      GridBagConstraints c = new GridBagConstraints();
      setLayout(gridBag);

      //chat info area - the first line
      c.fill = GridBagConstraints.HORIZONTAL;
      c.insets = new Insets(1,1,1,1);
      c.weightx = 0.0;
      c.gridwidth = 2;
      add(new JLabel("Here's my words: ", JLabel.CENTER), c);
      c.fill = GridBagConstraints.BOTH;
      c.weightx = 1.0;
      c.gridwidth = 6;
      myWords.addActionListener(new SendTextAction());
      add(myWords, c);
      c.fill = GridBagConstraints.HORIZONTAL;
      c.gridwidth = GridBagConstraints.REMAINDER;
      c.weightx = 0.0;
      sendText.addActionListener(new SendTextAction());
      add(sendText, c);

      // the second line
      sentTo.add(toOne);
      sentTo.add(toAll);
      toAll.setSelected(true);
      c.gridwidth = 2;
      c.weightx = 0.0;
      add(toAll, c);
      add(toOne, c);
      c.gridwidth = 1;
      c.weightx = 0.0;
      add(new JLabel(" Users:", JLabel.RIGHT), c);
      c.weightx =1.0;
      c.gridwidth = 3;
      add(userList, c);
      c.gridwidth = 2;
      c.gridwidth = GridBagConstraints.REMAINDER;
      sendTextSVG.addActionListener(new SendTextSVGAction());
      add(sendTextSVG, c);

      //the third line
      c.gridwidth = 1;
      c.weightx = 0.0;
      add(new JLabel(" Start:", JLabel.RIGHT), c);
      shapeStartPos.setEditable(false);
      c.weightx = 1.0;
      add(shapeStartPos, c);
      c.weightx = 0.0;
      add(new JLabel(" End:", JLabel.RIGHT), c);
      shapeEndPos.setEditable(false);
      c.weightx = 1.0;
      add(shapeEndPos, c);
      c.gridwidth = 1;
      c.weightx = 0.0;
      add(new JLabel(" SVGs:", JLabel.RIGHT), c);
      c.gridwidth = 3;
      c.weightx = 1.0;
      SVGs.addActionListener(new SelectSVGAction());
      add(SVGs, c);
      c.weightx = 0.0;
      c.gridwidth = 1;
      drawColorButton.addActionListener(new ColorAction());
      add(drawColorButton, c);
      c.gridwidth = 1;
      c.gridwidth = GridBagConstraints.REMAINDER;
      fillColorButton.addActionListener(new ColorAction());
      add(fillColorButton, c);

      //the forth line.
      c.gridwidth = 1;
      c.weightx = 0.0;
      add(new JLabel(" Width:", JLabel.RIGHT), c);
      c.weightx = 1.0;
      shapeWidth.setEditable(false);
      add(shapeWidth, c);
      c.weightx = 0.0;
      add(new JLabel(" Height:", JLabel.RIGHT), c);
      c.weightx = 1.0;
      shapeHeight.setEditable(false);
      add(shapeHeight, c);
      c.weightx = 0.0;
      c.gridwidth = 1;
      add(new JLabel(" Shapes:", JLabel.RIGHT), c);
      c.gridwidth = 3;
      c.weightx = 1.0;
      SVGShapes.addActionListener(new SelectShapeAction());
      add(SVGShapes, c);

      c.gridwidth = 1;
      filling.addChangeListener(new FillListener());
      add(filling, c);
      c.gridwidth = GridBagConstraints.REMAINDER;
      activateBtn.addActionListener(new ActivateAction(this));
      add(activateBtn, c);

      //the fifth line
      c.gridwidth = 1;
      c.weightx = 0.0;
      add(new JLabel(" Angle:", JLabel.RIGHT), c);
      c.weightx = 1.0;
      shapeAngle.addActionListener(new AngleAction());
      add(shapeAngle, c);
      c.weightx = 0.0;
      add(new JLabel(" Width:", JLabel.RIGHT));
      c.weightx = 1.0;
      shapeLineWidth.addActionListener(new WidthAction());
      add(shapeLineWidth, c);
      c.weightx = 0.0;
      add(new JLabel(" Styles:", JLabel.RIGHT), c);
      c.gridwidth = 3;
      c.weightx = 1.0;
      shapeLineStyle.addItem("CAP BUTT");
      shapeLineStyle.addItem("CAP ROUND");
      shapeLineStyle.addItem("CAP SQUARE");
      shapeLineStyle.addItem("JOIN BEVEL");
      shapeLineStyle.addItem("JOIN MITER");
      shapeLineStyle.addItem("JOIN ROUND");
      shapeLineStyle.addActionListener(new StyleAction());
      add(shapeLineStyle, c);
      userModes.add(chatMode);
      userModes.add(drawMode);
      c.weightx = 1.0;
      add(chatMode, c);
      c.gridwidth = GridBagConstraints.REMAINDER;
      add(drawMode, c);
      chatMode.setSelected(true);

   }

   public void setChatFocus()
   {
      myWords.requestFocus();
   }

   public void setEndPos(String p)
   {
      shapeEndPos.setText(p);
   }

   public void setStartPos(String p)
   {
      shapeStartPos.setText(p);
   }

   public void setLineWidth(int w)
   {
      shapeLineWidth.setText(w + "");
   }

   public void setWidth(int w)
   {
      shapeWidth.setText(w + "");
   }

   public void setHeight(int h)
   {
      shapeHeight.setText(h + "");
   }

   public void setUsers(ArrayList us)
   {
      userList.removeAllItems();
//      System.out.println("users: " + us.size());
      for(int i = 0; i < us.size(); i++)
      {
         userList.addItem(us.get(i));
      }
   }

   public void addShape(SVGShape shp)
   {
      String shape = shp.toString().substring(0,4) +
         " - " + (SVGShapes.getItemCount() + 1);
      SVGShapes.addItem(shape);
      SVGShapes.setSelectedItem(shape);
   }

   public void deleteShape(int index)
   {
//      System.out.println("I will delete shape " + index);
      SVGShapes.removeItemAt(index);
//      System.out.println("now, shapes is :  " + SVGShapes.getSelectedIndex());

      if(SVGShapes.getSelectedIndex() != -1)
         SVGShapes.setSelectedIndex(0);
   }

   public void setSelectedShape(int index)
   {
      SVGShapes.setSelectedIndex(index);
   }

   public boolean getFill()
   {
      return filling.isSelected();
   }

   public void addImage(SVGImage img)
   {
      String image = img.toString().substring(0,8) +
         " - " + (SVGs.getItemCount() + 1);
      SVGs.addItem(image);
      SVGs.setSelectedItem(image);
      SVGShapes.removeAllItems();
      System.out.println("Images: " + SVGs.getItemCount());
   }

   public void setAllShapes()
   {
      SVGShapes.removeAllItems();
//      vectorPanel.setSelectedSVG(SVGs.getSelectedIndex());
//      System.out.println("You have selected "+SVGs.getSelectedIndex()+"SVG");
      ArrayList al = vectorPanel.getAllShapes();
      for(int i = 0; i < al.size(); i++)
      {
         SVGShapes.addItem(al.get(i).toString().substring(0,4) +
         " - " + (SVGShapes.getItemCount() + 1));
      }
      vectorPanel.repaint();
   }

   public String getWords()
   {
      return myWords.getText();
   }

   public double getAngle()
   {
      double angle = 0;
      try
      {
         angle = Double.parseDouble(shapeAngle.getText());
      }
      catch(NumberFormatException nfe)
      {
         shapeAngle.setText("");
      }
      return angle;
   }


   class WidthAction extends AbstractAction
   {
      public void actionPerformed(ActionEvent e)
      {
         if(!vectorPanel.isEmpty())
         {
            vectorPanel.getShape().setLineWidth(
               Integer.parseInt(((JTextField)e.getSource()).getText()));
            vectorPanel.repaint();
         }
      }
   }

   class FillListener implements ChangeListener
   {
    public void stateChanged(ChangeEvent e)
      {
         if(!vectorPanel.isEmpty())
         {
            vectorPanel.getShape().setFill(
            ((JCheckBox)e.getSource()).isSelected());
            vectorPanel.repaint();
         }
      }
   }


   class ColorAction extends AbstractAction
   {
      public void actionPerformed(ActionEvent evt)
      {
         Color newColor = JColorChooser.showDialog(vectorPanel,
            "Select your favorite color", Color.black);
         Color oldcolor = vectorPanel.getCurrentColor();
         if(((JButton)evt.getSource()).getText().equals("Draw Color"))
         {
            System.out.println("you have choosed draw color!");
            if(newColor!=null)
            {
               vectorPanel.getShape().drawColor = newColor;
            }
         }
         else
         {
            System.out.println("you have choosed fill color!");
            if(newColor!=null)
            {
               vectorPanel.getShape().fillColor = newColor;
            }
         }
      }
   }

   class SelectSVGAction extends AbstractAction
   {
      public void actionPerformed(ActionEvent evt)
      {
//         if(!vectorPanel.isEmpty())
//         {
//            vectorPanel.setSelectedShape(SVGShapes.getSelectedIndex());
//            shapeLineWidth.setText(vectorPanel.getShape().getLineWidth()+ "");
//            vectorPanel.repaint();
//         }
         SVGShapes.removeAllItems();
         vectorPanel.setSelectedSVG(SVGs.getSelectedIndex());
         System.out.println("You have selected "+SVGs.getSelectedIndex()+"SVG");
         ArrayList al = vectorPanel.getAllShapes();
         for(int i = 0; i < al.size(); i++)
         {
            SVGShapes.addItem(al.get(i).toString().substring(0,4) +
               " - " + (SVGShapes.getItemCount() + 1));
         }
         vectorPanel.repaint();
      }
   }

   class SelectShapeAction extends AbstractAction
   {
      public void actionPerformed(ActionEvent evt)
      {
         if(!vectorPanel.isEmpty())
         {
            if(SVGShapes.getSelectedIndex() != -1)
               vectorPanel.setSelectedShape(SVGShapes.getSelectedIndex());

            System.out.println("index is "+SVGShapes.getSelectedIndex());
            System.out.println("shape is "+vectorPanel.getSelectedShape());
            shapeLineWidth.setText(vectorPanel.getShape().getLineWidth()+ "");
            vectorPanel.repaint();
         }
      }
   }

   class StyleAction extends AbstractAction
   {
      public void actionPerformed(ActionEvent evt)
      {
         if(!vectorPanel.isEmpty())
         {
            String style = (String)evt.getActionCommand();
            vectorPanel.getShape().setStyle(
               ((JComboBox)evt.getSource()).getSelectedItem() + "");

         }
         vectorPanel.repaint();
      }
   }

   class ActivateAction extends AbstractAction
   {
      ControlPanel controlPanel;

      public ActivateAction(ControlPanel cp)
      {
         controlPanel = cp;
      }
      public void actionPerformed(ActionEvent evt)
      {
         ActivateDialog activateDlg;

         if(!vectorPanel.isEmpty())
         {
            try
            {
               vectorPanel.getShape().setLineWidth(
                  Integer.parseInt(shapeLineWidth.getText()));
            }
            catch(NumberFormatException e)
            {
               System.out.println("You input a wrong format width!");
               shapeLineWidth.setText("1");
            }

            if(vectorPanel.getShape() instanceof SVGShapeRoundRectangle)
               activateDlg=
                  new ActivateDialog((JFrame)controlPanel.getRootPane().getParent(),
                  "RoundRectangle");
            else if(vectorPanel.getShape() instanceof SVGShapeArc)
               activateDlg=
                  new ActivateDialog((JFrame)controlPanel.getRootPane().getParent(),
                  "Arc");
            else if(vectorPanel.getShape() instanceof SVGShapeText)
               activateDlg=
                  new ActivateDialog((JFrame)controlPanel.getRootPane().getParent(),
                  "Text");
            else
               activateDlg=
                  new ActivateDialog((JFrame)controlPanel.getRootPane().getParent(),
                  "Operation");

            //place the dialog to the center of the screen.
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            Dimension screenSize = toolkit.getScreenSize();
            activateDlg.setBounds((screenSize.width - activateDlg.getSize().width) / 2 ,
               (screenSize.height -activateDlg.getSize().height) / 2 ,
            activateDlg.getSize().width , activateDlg.getSize().height);
            activateDlg.setVisible(true);

            //prepare to work


         }
//         vectorPanel.repaint();
      }
   }

   class AngleAction extends AbstractAction
   {
      public void actionPerformed(ActionEvent evt)
      {
         double angle = getAngle() * Math.PI / 180;
         vectorPanel.getShape().setAngle(angle);
         vectorPanel.repaint();
      }
   }

   class ActivateDialog extends JDialog
   {
      //for RoundRectangle
      JTextField roundXTf = new JTextField(4);
      JTextField roundYTf = new JTextField(4);

      //for Arc
      JTextField startAngleTf = new JTextField(4);
      JTextField arcAngleTf = new JTextField(4);
      JComboBox closureTypeCb = new JComboBox();

      //for Text
      JComboBox fontsCb = new JComboBox();
      JComboBox stylesCb = new JComboBox();
      JTextField textTf = new JTextField(100);

      //for operations
      ButtonGroup applyCG = new ButtonGroup();
      JRadioButton selectedRb = new JRadioButton("Apply to selected shape", true);
      JRadioButton allRb = new JRadioButton("Apply to all the shapes");

      //OK and Cancel buttons
      JButton okBtn = new JButton("OK");
      JButton cancelBtn = new JButton("Cancel");

      String status;

      public ActivateDialog(JFrame frame, String kind)
      {
         super(frame, kind);
         setSize(600, 250);
         Container c = getContentPane();
         c.setLayout(new GridLayout(10, 1));
         status = kind;

         //for RoundRectangle
         JPanel pane = new JPanel(new GridLayout(1, 4));
         c.add(new JLabel(" Round Rect - "));
         pane.add(new JLabel("Round X: ", JLabel.RIGHT));
         pane.add(roundXTf);
         roundXTf.setEditable(false);
         pane.add(new JLabel("Round Y: ", JLabel.RIGHT));
         pane.add(roundYTf);
         roundYTf.setEditable(false);
         c.add(pane);

         //for Text
         pane = new JPanel(new GridLayout(1,4));
         c.add(new JLabel(" Text - "));
         pane.add(new JLabel("Fonts: ", JLabel.RIGHT));
         pane.add(fontsCb);
         GraphicsEnvironment ge=
            GraphicsEnvironment.getLocalGraphicsEnvironment();
         String fontNames[]=ge.getAvailableFontFamilyNames();
         for(int i = 0; i < fontNames.length; i++)
         {
         fontsCb.addItem(fontNames[i]);
         }
         fontsCb.setEditable(false);
         pane.add(new JLabel("Styles: ", JLabel.RIGHT));
         pane.add(stylesCb);
         stylesCb.addItem("PLAIN");
         stylesCb.addItem("BOLD");
         stylesCb.addItem("ITALIC");
         stylesCb.addItem("BOLD+ITALIC");
         stylesCb.setEditable(false);
         pane.add(new JLabel("Content: ", JLabel.RIGHT));
         pane.add(textTf);
         textTf.setEditable(false);
         c.add(pane);


         //for Arc
         pane = new JPanel(new GridLayout(1, 6));
         c.add(new JLabel(" Arc - "));
         pane.add(new JLabel("start Angle: ", JLabel.RIGHT));
         pane.add(startAngleTf);
         startAngleTf.setEditable(false);
         pane.add(new JLabel("arc Angle: ", JLabel.RIGHT));
         pane.add(arcAngleTf);
         arcAngleTf.setEditable(false);
         pane.add(new JLabel("closure Type: ", JLabel.RIGHT));
         pane.add(closureTypeCb);
         closureTypeCb.setEditable(false);
         closureTypeCb.addItem("OPEN");
         closureTypeCb.addItem("CHORD");
         closureTypeCb.addItem("PIE");
         c.add(pane);


         //for Operations
         pane = new JPanel(new GridLayout(1, 3));
         c.add(new JLabel(" Operations - "));
         applyCG.add(selectedRb);
         applyCG.add(allRb);
         pane.add(new JLabel(""));
         pane.add(selectedRb);
         pane.add(allRb);

         c.add(pane);

         c.add(new JLabel("Note: "));

         pane = new JPanel(new GridLayout(1, 2));
         okBtn.addActionListener(new OKAction(this));
         cancelBtn.addActionListener(new CancelAction(this));
         pane.add(okBtn);
         pane.add(cancelBtn);
         c.add(pane);

         //make some of textfield editable
         if(kind.equals("RoundRectangle"))
         {
            roundXTf.setEditable(true);
            roundYTf.setEditable(true);
            //get old value
            roundXTf.setText(((SVGShapeRoundRectangle)
               vectorPanel.getShape()).getRoundX() + "");
            roundYTf.setText(((SVGShapeRoundRectangle)
               vectorPanel.getShape()).getRoundY() + "");

         }
         else if(kind.equals("Arc"))
         {
            startAngleTf.setEditable(true);
            arcAngleTf.setEditable(true);
            //get old value
            startAngleTf.setText(((SVGShapeArc)
               vectorPanel.getShape()).getStartAngle() + "");
            arcAngleTf.setText(((SVGShapeArc)
               vectorPanel.getShape()).getArcAngle() + "");
            closureTypeCb.setSelectedIndex(((SVGShapeArc)
               vectorPanel.getShape()).getClosureType());
         }
         else if(kind.equals("Text"))
         {
            textTf.setEditable(true);
            //get old value
            textTf.setText(((SVGShapeText)vectorPanel.getShape()).getText());
            fontsCb.setSelectedItem(((SVGShapeText)
               vectorPanel.getShape()).getFontName());
            stylesCb.setSelectedIndex(((SVGShapeText)
               vectorPanel.getShape()).getStyle());
         }

      }


   }

   class OKAction extends AbstractAction
   {
      ActivateDialog dialog;
      public OKAction(ActivateDialog dlg)
      {
         dialog = dlg;
      }

      public void actionPerformed(ActionEvent evt)
      {
         if(dialog.status.equals("RoundRectangle"))
         {
            try
            {
               ((SVGShapeRoundRectangle)vectorPanel.getShape()).setRoundX(
                  Integer.parseInt(dialog.roundXTf.getText()));
               ((SVGShapeRoundRectangle)vectorPanel.getShape()).setRoundY(
                  Integer.parseInt(dialog.roundYTf.getText()));

            }
            catch(NumberFormatException e)
            {
               System.out.println("You have input a wrong format number!");
               dialog.roundXTf.setText("10");
               dialog.roundYTf.setText("10");
            }
         }
         else if(dialog.status.equals("Arc"))
         {
            try
            {
               ((SVGShapeArc)vectorPanel.getShape()).setStartAngle(
                  Integer.parseInt(dialog.startAngleTf.getText()));
               ((SVGShapeArc)vectorPanel.getShape()).setArcAngle(
                  Integer.parseInt(dialog.arcAngleTf.getText()));
               ((SVGShapeArc)vectorPanel.getShape()).setClosureType(
                  dialog.closureTypeCb.getSelectedIndex());

            }
            catch(NumberFormatException e)
            {
               System.out.println("You have input a wrong format number!");
               dialog.startAngleTf.setText("0");
               dialog.arcAngleTf.setText("200");
               dialog.closureTypeCb.setSelectedItem("OPEN");
            }
         }
         else if(dialog.status.equals("Text"))
         {
            ((SVGShapeText)vectorPanel.getShape()).setStyle(
               dialog.stylesCb.getSelectedIndex());
            ((SVGShapeText)vectorPanel.getShape()).setFontName(
               (String)dialog.fontsCb.getSelectedItem());
            ((SVGShapeText)vectorPanel.getShape()).setText(
               dialog.textTf.getText());


         }
      dialog.dispose();
      vectorPanel.repaint();
      }
   }

   class CancelAction extends AbstractAction
   {
      ActivateDialog dialog;

      public CancelAction(ActivateDialog dlg)
      {
         dialog = dlg;
      }

      public void actionPerformed(ActionEvent evt)
      {
         dialog.dispose();
      }
   }

   class SendTextSVGAction extends AbstractAction
   {
      public void actionPerformed(ActionEvent evt)
      {
         if(chatClient.getClientMode().equals("online"))
         {
            if(myWords.getText().equals(""))
            {
               JOptionPane.showMessageDialog((JFrame)getRootPane().getParent(),
               "Hi, you need input some words to send!", "No text to send...",
               JOptionPane.ERROR_MESSAGE);
            }
            else
            {
               ChatInfo chatInfo = new ChatInfo(
                  "FROM:" + chatClient.getUserName(), myWords.getText(),
                  vectorPanel.getImage().getSVG());
               chatClient.send(chatInfo);
               myWords.setText("");
               myWords.requestFocus();
            }
         }
      }
   }

   class SendTextAction extends AbstractAction
   {
      public void actionPerformed(ActionEvent evt)
      {
         if(chatClient.getClientMode().equals("online"))
         {
            if(myWords.getText().equals(""))
            {
               JOptionPane.showMessageDialog((JFrame)getRootPane().getParent(),
               "Hi, + you need input some words to send!", "No text to send...",
               JOptionPane.ERROR_MESSAGE);
            }
            else
            {
               ChatInfo chatInfo = new ChatInfo(
                  "FROM:" + chatClient.getUserName(), myWords.getText(), null);
               chatClient.send(chatInfo);
               myWords.setText("");
               myWords.requestFocus();
            }
         }
      }
   }
}
