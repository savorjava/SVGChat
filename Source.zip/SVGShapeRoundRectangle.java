//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGShapeRoundRectangle.java

import java.awt.*;
import java.awt.geom.*;

public class SVGShapeRoundRectangle extends SVGShape
{
   private RoundRectangle2D.Double round;
   private int roundX = 9;
   private int roundY = 9;

   public SVGShapeRoundRectangle()
   {
      round = new RoundRectangle2D.Double(0,0,0,0,0,0);
   }

   /**
   @roseuid 3C766E5A024B
   */
   public void draw(Graphics g)
   {
      super.draw(g);

      rectangle = round.getBounds();
      round.archeight = roundY;
      round.arcwidth = roundX;
      Graphics2D g2 = (Graphics2D)g;
      AffineTransform old = g2.getTransform();
      g2.scale(scale, scale);
      g2.rotate(angle, Math.abs(((Point2D)positions.get(1)).getX() -
         round.getWidth() / 2),
         Math.abs(((Point2D)positions.get(1)).getY() -
         round.getHeight() / 2));
      g2.setStroke(stroke);
      if(isFill)
      {
         g2.setColor(fillColor);
         g2.fill(round);
      }
      else
      {
         g2.setColor(drawColor);
         g2.draw(round);
      }
      g2.setTransform(old);
      generateSVG();
//      System.out.println(SVGFormat);
   }

   public void addPosition(Point2D p2)
   {
         positions.add(p2);
         positions.add(p2);
   }

   public void setPosition(Point2D p2, int address)
   {
      positions.set(address - 1, p2);
      round.setFrameFromDiagonal((Point2D)positions.get(0),
         (Point2D)positions.get(1));
   }

   public void setSelected(boolean b)
   {
      selected = b;
   }

   public String toString()
   {
      return "Round:" + round.getX()+ "," + round.getY() + " - " +
         round.width + "," + round.height;
   }

   public int getRoundX()
   {
      return roundX;
   }

   public int getRoundY()
   {
      return roundY;
   }

   public void setRoundX(int rx)
   {
      roundX = rx;
   }

   public void setRoundY(int ry)
   {
      roundY = ry;
   }

   public void generateSVG()
   {

      SVGFormat = "<rect x=\"" + round.getX() + "\" " +
            "y=\"" + round.getY() + "\" " +
            "width=\"" + round.width + "\" " +
            "height=\"" + round.height + "\" " +
            "rx=\"" + round.arcwidth + "\" " +
            "ry=\"" + round.archeight + "\" " +
            "stroke=\"" +
            (!isFill ? "#" + Integer.toHexString(drawColor.getRGB()).substring(2) : "none") + "\" " +
            "fill=\"" +
            (isFill ? "#" + Integer.toHexString(fillColor.getRGB()).substring(2) : "none") + "\" " +
            "stroke-width=\"" + lineWidth + "\" " +
            "/>";
   }
}
