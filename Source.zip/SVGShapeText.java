import SVGShape;

/**
 * Title:        SVGChat
 * Description:  This system is for chating with SVG(Scalable Vector Graphics).
 * Copyright:    Copyright (c) 2002
 * Company:      HUST
 * @author Sha Jin
 * @version 1.0
 */

import java.awt.*;
import java.awt.geom.*;

public class SVGShapeText extends SVGShape
{
   private String text = "Activate to Change!";
   private String fontName = "Arial";
   private int style = 0;

   public SVGShapeText() {
      text = "Activate to Change";
      lineWidth = 18;
   }

   public void draw(Graphics g)
   {
      Graphics2D g2 = (Graphics2D)g;
      AffineTransform old = g2.getTransform();
      FontMetrics metrics = g2.getFontMetrics();
      int width = metrics.stringWidth( text );
      int height = metrics.getHeight();
      rectangle = new Rectangle((int)((Point2D)positions.get(0)).getX(),
         (int)((Point2D)positions.get(0)).getY() - height, width, height);
      g2.rotate(angle, ((Point2D)positions.get(0)).getX(),
         ((Point2D)positions.get(0)).getY());
      g2.setStroke(new BasicStroke(1, cap, join));
      g2.setColor(drawColor);
      if(selected)
      {
         double x = ((Point2D)positions.get(0)).getX() - SIZE / 2;
         double y = ((Point2D)positions.get(0)).getY() - SIZE / 2;
         Rectangle2D r = new Rectangle2D.Double(x, y, SIZE, SIZE);
         g2.draw(r);
      }

      g2.scale(scale, scale);
      g2.setStroke(stroke);
      g2.setColor(drawColor);
      g2.setFont(new Font(fontName, style, lineWidth));
      float x = (float)((Point2D.Double)positions.get(0)).getX();
      float y = (float)((Point2D.Double)positions.get(0)).getY();
      g2.drawString(text, x, y);
      g2.setTransform(old);
      generateSVG();
//      System.out.println(SVGFormat);

   }

   public void addPosition(Point2D p2)
   {
         positions.add(p2);
         //do this is for not be optimized by Java!!!
         Point2D newP2 = new Point2D.Double(0.0, 0.0);
         positions.add(newP2);
   }

   public void setPosition(Point2D p2, int address)
   {
      positions.set(address - 1, p2);
   }

   public void setSelected(boolean b)
   {
      selected = b;
   }

   public String getFontName()
   {
      return fontName;
   }

   public String getText()
   {
      return text;
   }

   public int getStyle()
   {
      return style;
   }

   public void setFontName(String name)
   {
      fontName = name;
   }

   public void setText(String t)
   {
      text = t;
   }

   public void setStyle(int s)
   {
      style = s;
   }

   public String toString()
   {
      return "Text: " + text;
   }

   public void generateSVG()
   {

      SVGFormat = "<text x=\"" + (float)((Point2D.Double)positions.get(0)).getX() +
          "\" " + "y=\"" + (float)((Point2D.Double)positions.get(0)).getY() +
          "\" " + "font-family=\"" + fontName + "\" font-size=\"" + lineWidth +
          "\" fill=\"#" + Integer.toHexString(drawColor.getRGB()).substring(2) + "\">" +
//         "stroke=\"#" + Integer.toHexString(drawColor.getRGB()).substring(2) + "\" " +
//         "stroke-width=\"" + lineWidth + "\" " +
//         "/>";
         text + "</text>";
   }
}
