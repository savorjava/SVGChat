//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGShapeLine.java

import java.awt.*;
import java.awt.geom.*;

public class SVGShapeLine extends SVGShape
{
   private Line2D line;

   public SVGShapeLine()
   {
      line = new Line2D.Double(new Point2D.Double(0.0, 0.0),
         new Point2D.Double(0.0, 0.0));
   }

   /**
   @roseuid 3C766E3A0097
   */
   public void draw(Graphics g)
   {
      super.draw(g);

      rectangle = line.getBounds();
      Graphics2D g2 = (Graphics2D)g;
      AffineTransform old = g2.getTransform();
      g2.scale(scale, scale);
      g2.setStroke(stroke);
      g2.setColor(drawColor);
      g2.rotate(angle, Math.abs(((Point2D)positions.get(1)).getX() -
         line.getBounds().getWidth() / 2),
         Math.abs(((Point2D)positions.get(1)).getY() -
         line.getBounds().getHeight() / 2));
      g2.draw(line);
      g2.setTransform(old);

      generateSVG();
//      System.out.println(SVGFormat);
   }

   public void addPosition(Point2D p2)
   {
         positions.add(p2);
         positions.add(p2);
   }

   public void setPosition(Point2D p2, int address)
   {
      positions.set(address - 1, p2);
      line.setLine((Point2D)positions.get(0), (Point2D)positions.get(1));

   }

   public void setSelected(boolean b)
   {
      selected = b;
   }

   public String toString()
   {
      return "Line: " + line.getX1()+ "," + line.getY1() + " - " +
         line.getX2() + "," + line.getY2();
   }

   public void generateSVG()
   {

      SVGFormat = "<line x1=\"" + line.getX1() + "\" " +
         "y1=\"" + line.getY1() + "\" " +
         "x2=\"" + line.getX2() + "\" " +
         "y2=\"" + line.getY2() + "\" " +
         "stroke=\"#" + Integer.toHexString(drawColor.getRGB()).substring(2) + "\" " +
         "stroke-width=\"" + lineWidth + "\" " +
         "/>";
   }

}
