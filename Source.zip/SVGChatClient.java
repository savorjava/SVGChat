//Source file: e:\\jbuilder4\\jdk1.3\\lib\\SVGChatClient.java

import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

//import javax.swing.*;

public class SVGChatClient implements Runnable
{
   private String user;
   private ChatInfo chatInfo;
   private Socket socket = null;
   private ObjectInputStream in = null;
   private ObjectOutputStream out = null;
   private File SVGFile = null;
   private File recordFile = null;
   public ChatInfo theChatInfo;
   public User theUser;
   public SVGPanel theSVGPanel;
   public ChatClientFrame chatClientFrame;

   private int timeout = 300000;
   private String host = "localhost";
   private int port = 4321;
   private String clientMode = "offline"; /*describe the state of connecting,
                                          could be "online" or "offline"*/
   private Thread clientThread = null;

   private SVGParser svgParser;

   public SVGChatClient()
   {
   }

   /**
   @roseuid 3C7B4EA8006A
   */
   public void run()
   {
      while(clientMode.equals("online"))
      {
         try
         {
            Thread.sleep(500);
            ChatInfo ci = (ChatInfo)in.readObject();
//            System.out.println("I got a chatInfo!" + chatInfo.getCommand() + "," + chatInfo.getChatWords());
            if(ci.getCommand().substring(0,5).equals("FROM:"))
            {
               chatClientFrame.printInfo(
                  ci.getCommand().substring(5) + " : " + ci.getChatWords() + "\n\n");
               System.out.println(ci.getSVGFormat());
               if(ci.getSVGFormat() != null)
                  chatClientFrame.addImage(
                     svgParser.parserInit(ci.getSVGFormat()));
            }
            else if(ci.getCommand().equals("COMM:CLOSE"))
            {
               in.close();
               out.close();
               socket.close();
               setClientModeoff();
            }
            else if(ci.getCommand().equals("COMM:PUSH"))
            {
               chatClientFrame.setUsers(ci.getUsers());
               System.out.println("come from push: " + ci.getUsers().size());
               chatClientFrame.printInfo(ci.getChatWords() + "\n\n");
            }
         }
         catch(ClassNotFoundException e)
         {
            System.out.println("can't read text and SVG !");
         }
         catch(IOException e)
         {
            System.out.println("What's wrong: " + e);
            try
            {
               in.close();
               out.close();
               socket.close();
            }
            catch(IOException ioe)
            {
               System.out.println("Can't close client when server was closed");
            }
            setClientModeoff();
            chatClientFrame.clearInfo();
            chatClientFrame.printInfo("SVG Chat Server have been Closed!");
         }
         catch(InterruptedException e)
         {
            System.out.println(e);
         }
      }
   }

   /**
   @roseuid 3C7BB6270012
   */
   public void send(ChatInfo info)
   {
      try
      {
//         System.out.println("I will send : "+info.getCommand()+","+info.getChatWords());
         out.writeObject(info);
      }
      catch(IOException e)
      {
         System.out.println("can't send text and SVG:"+e);
      }
   }

   /**
   @roseuid 3C7BB656001A
   */
   public void login()
   {
   }

   /**
process the information that received from server.
   @roseuid 3C7BB6F000D0
   */
   public void processInfo()
   {
   }

   /**
   @roseuid 3C7C7FA101DC
   */
   public static void main(String[] args)
   {
      SVGChatClient chatClient= new SVGChatClient();
      //show help messages
      System.out.println("usage: java -jar SVGChatClient [host] [port]");
      System.out.println("example: java -jar SVGChatClient");
      System.out.println("     or  java -jar SVGChatClient localhost 4321");
      System.out.println("     or  java -jar SVGChatClient 192.168.0.1");
      System.out.println("===============================================");
      //show startup information.
      if(args.length == 2)
      {
         chatClient.host = args[0];
         chatClient.port = Integer.parseInt(args[1]);
         System.out.println("OK! you wanna connect to " + args[0] + ":" + args[1] + " ...");
      }
      if(args.length == 1)
      {
         chatClient.host = args[0];
         System.out.println("OK! you wanna connect to " + args[0] + ":4321" + " ...");
      }
      if(args.length == 0)
         System.out.println("OK! you wanna connect to localhost:4321" + " ...");

      // begin the client application.
//      chatClientFrame = new ChatClientFrame("SVG Chat is testing" , chatClient);
      chatClient.init();

   }

   public void init()
   {


      //creat and show the frame of the client application.
      chatClientFrame = new ChatClientFrame("SVG Chat is testing" , this);
//      System.out.println(System.getProperty("user.dir"));
      chatClientFrame.addWindowListener(new WindowAdapter()
         {
            public void windowClosing(WindowEvent e)
            {
               clientMode = "offline";
               System.out.println("Closing frame!");
               System.exit(0);
            }
         });

   }

   public void login(ChatClientFrame.LoginDialog dialog)
   {

      //create the socket
      try
      {
         boolean login = false;
         user = dialog.getName();
         chatInfo = new ChatInfo("LOGI:" + user, null, null);

         socket = new Socket((String)dialog.getHost() , dialog.getPort());

         //have to place in after setting out, why?
         out = new ObjectOutputStream(socket.getOutputStream());
         in = new ObjectInputStream(socket.getInputStream());

//         socket.setSoTimeout(2000);

         //send your first words!
         while(!login)
         {
//            System.out.println("I will write to server!" +chatInfo.getCommand());

            out.writeObject(chatInfo);
            out.flush();

            try
            {
               chatInfo = (ChatInfo)in.readObject();
//               System.out.println("first reply: " + chatInfo.getCommand());
            }
            catch(ClassNotFoundException e)
            {
               System.out.println("Can't get object: " + e);
            }
//            catch(IOException ie)
//            {
//               System.out.println("first replay has read error:" + ie);
//            }
            //if user wanna close the connection must wait
            //server reply a close command after user send
            //a close command to server.
            if(chatInfo.getCommand().equals("COMM:CLOSE"))
            {
               socket.close();
               setClientModeoff();
            }
            //"DUP" means the user name have existed, need to re-input.
            if(chatInfo.getCommand().equals("INFO:DUP"))
            {
//                     System.out.println("this DUP");
               new InputNameDialog(chatClientFrame,
                  "Please re-input user name...", true, dialog.getName());

//               System.out.println("after dialog:" + chatInfo.getCommand());
            }
            else
            {
               //startup the thread!
               setClientModeon();
               chatClientFrame.clearInfo();
               chatClientFrame.printInfo(" - - - >" + chatInfo.getChatWords() + " <- - - \n\n");
               chatClientFrame.setUsers(chatInfo.getUsers());
               break;
            }
         }
      }
      catch(IOException e)
      {
         System.out.println("Cannot connect to host, you are in offline state:" + e);
         chatClientFrame.clearInfo();
         chatClientFrame.printInfo("Sorry! "+ dialog.getName() + ",\n" +
         "Cannot connect to host, you are in offline state." +
         "Please confirm host and port from Administrator!");
      }

   }

   //call this operator when you want to exit or disconnect.
   public void setClientModeoff()
   {
      System.out.println("Frame stop the thread!");
      clientMode = "offline";
   }

   public void setClientModeon()
   {
      System.out.println("Frame start the thread!");
      clientMode = "online";
      clientThread = new Thread(this);
      System.out.println("thread will run!");
      clientThread.start();
   }

   public String getClientMode()
   {
      return clientMode;
   }

   public String getHost()
   {
      return host;
   }

   public int getPort()
   {
      return port;
   }

   public String getUserName()
   {
      return user;
   }

   public void setOff()
   {
      try
      {
         out.writeObject(new ChatInfo("COMM:CLOSE", null, null));
      }
      catch(IOException ioe)
      {
         System.out.println("write to server error when close the connection");
      }
   }

   public void setSVGParser(SVGParser parser)
   {
      svgParser = parser;
   }




   class InputNameDialog extends JDialog implements ActionListener
   {
      private JTextField nameTf = new JTextField(20);
      private JButton confirmBtn = new JButton("OK");
      private JButton cancelBtn = new JButton("Cancel");
      private String userName;

      public InputNameDialog(JFrame frame, String title, boolean m, String name)
      {
         super(frame, title, m);
         userName = name;
         Container c = getContentPane();
         c.setLayout(new GridLayout(3, 2));
         c.add(new JLabel("The \"" + userName +
            "\" have be used!", JLabel.CENTER));
         c.add(new JLabel(""));
         c.add(new JLabel("Please re-input another name:", JLabel.LEFT));
         c.add(nameTf);
         c.add(confirmBtn);
         confirmBtn.addActionListener(this);
         cancelBtn.addActionListener(this);
         c.add(cancelBtn);
         setSize(400,150);
         //don't close window by this way!
         setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
         //place dialog into center!
         Toolkit toolkit = Toolkit.getDefaultToolkit();
         Dimension screenSize = toolkit.getScreenSize();
         setBounds((screenSize.width - 400) / 2 ,
            (screenSize.height - 150) / 2 , 400 , 150);
         setVisible(true);
      }

      public void actionPerformed(ActionEvent evt)
      {
         if(evt.getActionCommand().equals("OK"))
         {
            if(nameTf.getText().equals(""))
               nameTf.setText("input name");
            else
            {
               user = nameTf.getText();
               chatInfo.setCommand("LOGI:" + user);
               System.out.println("have chagned: " + chatInfo.getCommand());
               dispose();
            }
         }
         else
         {
            chatInfo.setCommand("COMM:CLOSE");
            dispose();
         }
      }
   }




}
